import React, { useState, useRef, useEffect, useCallback, useId } from 'react';
import { Trophy, Flag, Menu, ArrowRight, BookOpen, Ship, Route, Medal, ChartColumnBig, InfoIcon, Eye, Settings2, ArrowBigLeft} from 'lucide-react';
import { createPortal } from 'react-dom';
import { postcodeAreas, ferryLinks, bridgeLinks } from './postcodeAreas';
import useSvgPan from './hooks/useSvgPan';
import OnboardingTutorial from './components/OnboardingTutorial';
import * as Daily from './dailyManager';


 import StatsPage from './pages/StatsPage.jsx';
 import AchievementsPage from './pages/AchievementsPage.jsx';
import Settings from './pages/Settings.jsx';
import PrivacyPolicy from './pages/PrivacyPolicy.jsx';

 import { 
  achievements,
  evaluateAndUnlockAchievements, 
  checkAndUnlockMetaAchievements, 
  logAchievementsToGA,
  unlockStreaksFor
} from './achievements.js';

import ToastShell from './components/toast/ToastShell';
import AchievementToast from './components/toast/AchievementToast';
import ErrorToast from './components/toast/ErrorToast';
import TipToast from './components/toast/TipToast';
import GameBoard from './components/game/GameBoard';
import GameMap from './components/game/GameMap';
import GameModal from './components/game/GameModal';
import MobileCodeScroller from './components/game/MobileCodeScroller';

import './firebase'
import useCloudSync from './hooks/useCloudSync';
import {addGameToHistory} from './utils/historyUtils.js';
import AuthButton from './components/AuthButton';
import { recordLifetimeMove } from './utils/lifetimeMeta';
import {
  DIFFS,
  GAME_HISTORY_KEY,
  STREAK_KEY_V2,
  USED_BRIDGES_KEY,
  USED_FERRIES_KEY,
  VISITED_KEY,
  addUsedBridgeEdge,
  addUsedFerryEdge,
  addVisited,
  dailySessionKey,
  emptySnapshot,
  getLifetimeVisitedCount,
  getLocalSnapshot,
  readJSON,
  writeLocalSnapshot,
} from './utils/storageUtils';
import {
  abandonActiveAttempt,
  finishAttempt,
  recordAttemptEvent,
  startAttempt,
} from './utils/attemptAnalytics';
import { syncAttemptSummary } from './utils/analyticsSync';


import { auth } from './firebase';

console.log('UID:', auth.currentUser?.uid);

// ---- Module-level constants -------------------------------------------------
// Define the World
const WORLD = { x: 0, y: 0, width: 15000, height: 17500 }; // <- your existing values
const MIN_SCALE = 0.1;
const MAX_SCALE = 30;
//const ZOOM_STEP = 1.25; // button zoom factor

// Daily helpers
const DAILY_STREAK_KEY = 'pp_daily_streak_v1'; // {count:number, lastWinDate:'YYYY-MM-DD'}
const UI_THEME_KEY = 'pp:theme:v1';
const UI_COLORBLIND_KEY = 'pp:colorblind:v1';
const INPUT_MODE_KEY = 'pp:inputMode:v1';
const LARGE_CONTROLS_KEY = 'pp:largeControls:v1';
const HIGH_CONTRAST_MAP_KEY = 'pp:highContrastMap:v1';
const MAP_STYLE_KEY = 'pp:mapStyle:v1';
const TEXT_SIZE_KEY = 'pp:textSize:v1';

function parseUTC(dateStr){ return new Date(dateStr + 'T00:00:00Z'); }
function daysBetweenUTC(a,b){
  const ms = parseUTC(b).getTime() - parseUTC(a).getTime();
  return Math.round(ms / 86400000);
}
function loadDailyStreak(){
  try { return JSON.parse(localStorage.getItem(DAILY_STREAK_KEY) || 'null'); } catch { return null; }
}
function saveDailyStreak(count, lastWinDate){
  localStorage.setItem(DAILY_STREAK_KEY, JSON.stringify({ count, lastWinDate }));
}
//function todayUTC(){ return new Date().toISOString().slice(0,10); }

let _confettiPromise;

/** lazy import so we don't bloat the initial bundle */
function getConfetti() {
  if (!_confettiPromise) _confettiPromise = import('canvas-confetti');
  return _confettiPromise;
}

function prefersReducedMotion() {
  return (
    typeof window !== 'undefined' &&
    window.matchMedia &&
    window.matchMedia('(prefers-reduced-motion: reduce)').matches
  );
}

async function fireVictoryConfetti() {
  if (prefersReducedMotion()) return;

  try {
    const { default: confetti } = await getConfetti();

    // Two quick corner bursts + a center pop
    const z = 2147483648; // above your modal overlay (which is 2147483647)
    const base = Math.max(120, Math.min(220, Math.round(window.innerWidth / 6)));

    confetti({ particleCount: Math.round(base * 0.45), spread: 20, startVelocity: 55, origin: { x: 0.15, y: 0.2 }, zIndex: z });
    confetti({ particleCount: Math.round(base * 0.6), spread: 50, startVelocity: 55, origin: { x: 0.5, y: 0.2 }, zIndex: z });
    confetti({ particleCount: Math.round(base * 0.75), spread: 70, startVelocity: 55, origin: { x: 0.75, y: 0.2 }, zIndex: z });
    confetti({ particleCount: Math.round(base * 0.9), spread: 90, startVelocity: 55, origin: { x: 0.9, y: 0.2 }, zIndex: z });

    setTimeout(() => {
      confetti({ particleCount: Math.round(base * 0.6), spread: 100, scalar: 0.9, origin: { x: 0.5, y: 0.25 }, zIndex: z });
    }, 180);

    // optional: tidy up the canvas after a moment
    setTimeout(() => confetti.reset(), 5000);
  } catch {
    // fail silently if the import or canvas fails
  }
}


// Touch device - Mobiles
function useIsTouchDevice() {
  const [isTouch, setIsTouch] = React.useState(false);

  React.useEffect(() => {
    const mqCoarse = window.matchMedia?.('(pointer: coarse)');
    const mqFine   = window.matchMedia?.('(pointer: fine)');
    const mqHover  = window.matchMedia?.('(hover: hover)');

    const detect = () => {
      const canHover = !!mqHover?.matches;       // true on mice/trackpads
      const isFine   = !!mqFine?.matches;        // precise pointer available
      const isCoarse = !!mqCoarse?.matches;      // finger-ish pointer available
      const hasTouch = (navigator.maxTouchPoints || 0) > 0;

      // Desktop if it can hover OR has a fine pointer.
      // Only treat as "mobile" when it cannot hover and only offers coarse touch.
      const mobileLike = !canHover && (isCoarse || hasTouch) && !isFine;

      setIsTouch(mobileLike);
    };

    detect();
    mqCoarse?.addEventListener?.('change', detect);
    mqFine?.addEventListener?.('change', detect);
    mqHover?.addEventListener?.('change', detect);
    return () => {
      mqCoarse?.removeEventListener?.('change', detect);
      mqFine?.removeEventListener?.('change', detect);
      mqHover?.removeEventListener?.('change', detect);
    };
  }, []);

  return isTouch;
}









export default function PostcodePursuit() {
// ------------------- STATE & REFS (unchanged from your file) --------------
const [gameState, setGameState] = useState('menu');
const [difficulty, setDifficulty] = useState('normal');
const [startArea, setStartArea] = useState('');
const [targetArea, setTargetArea] = useState('');
const [currentPath, setCurrentPath] = useState([]);
const [guesses, setGuesses] = useState([]);
const [gameWon, setGameWon] = useState(false);
const [optimalPath, setOptimalPath] = useState([]);
const [achievementToasts, setAchievementToasts] = useState([]);
const pendingAchievementItemsRef = useRef([]);
const pendingAchievementTimerRef = useRef(null);

const flushAchievementBatch = useCallback(() => {
  const list = pendingAchievementItemsRef.current.filter(Boolean);
  pendingAchievementItemsRef.current = [];

  if (pendingAchievementTimerRef.current) {
    window.clearTimeout(pendingAchievementTimerRef.current);
    pendingAchievementTimerRef.current = null;
  }

  if (!list.length) return;

  const payload = list.length === 1
    ? list[0]
    : {
        id: `achievement-group-${Date.now()}-${Math.random().toString(36).slice(2, 8)}`,
        kind: 'group',
        items: list,
      };

  setAchievementToasts(q => [...q, payload]);
}, []);

const enqueueAchievementBatch = useCallback((items) => {
  const list = Array.isArray(items) ? items.filter(Boolean) : [];
  if (!list.length) return;

  pendingAchievementItemsRef.current = [
    ...pendingAchievementItemsRef.current,
    ...list,
  ];

  if (pendingAchievementTimerRef.current) {
    window.clearTimeout(pendingAchievementTimerRef.current);
  }

  pendingAchievementTimerRef.current = window.setTimeout(() => {
    flushAchievementBatch();
  }, 500);
}, [flushAchievementBatch]);

const clearAchievementToasts = useCallback(() => {
  pendingAchievementItemsRef.current = [];
  if (pendingAchievementTimerRef.current) {
    window.clearTimeout(pendingAchievementTimerRef.current);
    pendingAchievementTimerRef.current = null;
  }
  setAchievementToasts([]);
}, []);

useEffect(() => {
  return () => {
    if (pendingAchievementTimerRef.current) {
      window.clearTimeout(pendingAchievementTimerRef.current);
    }
  };
}, []);
const [showHints, setShowHints] = useState(false);
const [dailyGaveUp, setDailyGaveUp] = useState(false);
const [betaDailyMode, setBetaDailyMode] = useState(false);
const [journeyExpanded, setJourneyExpanded] = useState(false);
const [mobileControlsTab, setMobileControlsTab] = useState('enter');
  const [elapsedMs, setElapsedMs] = useState(0);

const [showOutlines, setShowOutlines] = useState(true);
const [showLabels, setShowLabels] = useState(true);
const suppressClickUntilRef = useRef(0);
const [flashAreas, setFlashAreas] = useState([]);
const [showOptimal, setShowOptimal] = useState(false);
  const [showAbout, setShowAbout] = useState(false);  
const [dailyMode, setDailyMode] = useState(false);
const [dailyDate, setDailyDate] = useState(null);             // 'YYYY-MM-DD' (UTC)


  const [victoryOpen, setVictoryOpen] = useState(false);

const ONBOARDING_KEY = 'pp:onboardingComplete:v1';


const isActiveRound = () => gameState === 'playing' && !gameWon;

const [showTutorial, setShowTutorial] = useState(false);
const [consentResolved, setConsentResolved] = useState(
  () => !!localStorage.getItem('pp_consents')
);
const [uiTheme, setUiTheme] = useState(() => {
  const stored = localStorage.getItem(UI_THEME_KEY);
  return ['system', 'light', 'dark'].includes(stored) ? stored : 'system';
});
const [colorblindFriendly, setColorblindFriendly] = useState(
  () => localStorage.getItem(UI_COLORBLIND_KEY) === 'true'
);
const [inputMode, setInputMode] = useState(() => {
  const stored = localStorage.getItem(INPUT_MODE_KEY);
  return ['auto', 'mobile', 'desktop'].includes(stored) ? stored : 'auto';
});
const [largeControls, setLargeControls] = useState(
  () => localStorage.getItem(LARGE_CONTROLS_KEY) === 'true'
);
const [mapStyle, setMapStyle] = useState(() => {
  const stored = localStorage.getItem(MAP_STYLE_KEY);
  if (['standard', 'contrast', 'night'].includes(stored)) return stored;
  return localStorage.getItem(HIGH_CONTRAST_MAP_KEY) === 'true' ? 'contrast' : 'standard';
});
const [textSize, setTextSize] = useState(() => {
  const stored = localStorage.getItem(TEXT_SIZE_KEY);
  return ['normal', 'large'].includes(stored) ? stored : 'normal';
});

const canClickAreas = difficulty === 'easy';
const roundResolved = gameWon || dailyGaveUp;

// --- Soft Par helpers (Daily only) ---
const parForOptimal = (optimalMoves) => Math.max(1, Math.ceil(optimalMoves * 1.25));
const parDelta = (moves, par) => moves - par; // negative = under par
function parPhrase(moves, par) {
  if (!Number.isFinite(par)) return null;
  const d = parDelta(moves, par);
  if (d < 0) return `${Math.abs(d)} under par`;
  if (d === 0) return 'on par';
  return `${d} over par`;
}
const [dailyPar, setDailyPar] = useState(null);

useEffect(() => {
  document.documentElement.dataset.ppTheme = uiTheme;

  if (colorblindFriendly) {
    document.documentElement.dataset.ppColorblind = 'true';
  } else {
    delete document.documentElement.dataset.ppColorblind;
  }
  if (largeControls) {
    document.documentElement.dataset.ppLargeControls = 'true';
  } else {
    delete document.documentElement.dataset.ppLargeControls;
  }
  if (['contrast', 'night'].includes(mapStyle)) {
    document.documentElement.dataset.ppMapStyle = mapStyle;
  } else {
    delete document.documentElement.dataset.ppMapStyle;
  }
  delete document.documentElement.dataset.ppHighContrastMap;
  if (textSize === 'large') {
    document.documentElement.dataset.ppTextSize = 'large';
  } else {
    delete document.documentElement.dataset.ppTextSize;
  }

  localStorage.setItem(UI_THEME_KEY, uiTheme);
  localStorage.setItem(UI_COLORBLIND_KEY, colorblindFriendly ? 'true' : 'false');
  localStorage.setItem(INPUT_MODE_KEY, inputMode);
  localStorage.setItem(LARGE_CONTROLS_KEY, largeControls ? 'true' : 'false');
  localStorage.setItem(MAP_STYLE_KEY, mapStyle);
  localStorage.setItem(HIGH_CONTRAST_MAP_KEY, mapStyle === 'contrast' ? 'true' : 'false');
  localStorage.setItem(TEXT_SIZE_KEY, textSize);
}, [uiTheme, colorblindFriendly, inputMode, largeControls, mapStyle, textSize]);

const isTouch = useIsTouchDevice();
const useMobileInput = inputMode === 'mobile' || (inputMode === 'auto' && isTouch);
const analyticsInputStyle =
  inputMode === 'auto'
    ? (useMobileInput ? 'auto_scroller' : 'auto_keyboard')
    : inputMode === 'mobile'
      ? 'scroller'
      : 'keyboard';

// Geometric helpers (centroids etc)
const roundIdRef = useRef(null);
const landClipId = useId();
const centroidsRef = useRef({});
 const getCenter = useCallback(
   (code) => postcodeAreas[code]?.center || centroidsRef.current[code] || null,
   []
 );

useEffect(() => {
  if (victoryOpen) {
    fireVictoryConfetti();
  }
}, [victoryOpen]);

// Pan/zoom state
const svgRef = useRef(null);
const gRef = useRef(null);
const contentRef = useRef(null);
const didAutoFitRef = useRef(false);
const hasFitRef = useRef(false);
const controlsRef = useRef(null);
const journeyRailRef = useRef(null);


//Toggle for Master Mode
const [masterMode, setMasterMode] = useState(false);

const edgeType = (a, b) => {
  if (ferryAdj.get(a)?.has(b)) return 'ferry';
  if (bridgeAdj.get(a)?.has(b)) return 'bridge';
  return 'land';
};

const getCloudProgressSnapshot = useCallback(
  () => getLocalSnapshot({ includeAnalytics: false }),
  []
);

const { user, queueSave, saveNow, overwriteNow } =
  useCloudSync(getCloudProgressSnapshot, writeLocalSnapshot);

// One helper for everywhere you persist
const onPersist = React.useCallback((immediate = false) => {
  if (!user) return;
  return immediate ? saveNow() : queueSave();
}, [user, queueSave, saveNow]);

// -------- Daily Challenge setup --------

const [dailyDifficulty, setDailyDifficulty] = useState(null); // 'easy'|'normal'|'hard'|'master'

const MAX_DAILY_HINTS = 3;
const [hintsUsed, setHintsUsed] = useState(0);

function todayUTC() { return new Date().toISOString().slice(0,10); } // YYYY-MM-DD

const saveDailySessionSnapshot = React.useCallback(() => {
  if (!dailyMode || !dailyDate || !dailyDifficulty) return;
  const elapsedSoFar =
    (elapsedMs || 0) + (gameStartRef.current ? Math.max(0, performance.now() - gameStartRef.current) : 0);

  const snapshot = {
    date: dailyDate,
    difficulty: dailyDifficulty,
    startArea, targetArea, currentPath, guesses, hintsUsed,
    optimalPath, elapsedMs: Math.floor(elapsedSoFar),
    gameWon, showOptimal, victoryOpen,
    par: dailyPar,
    savedAt: new Date().toISOString(),
  };
  localStorage.setItem(dailySessionKey(dailyDifficulty), JSON.stringify(snapshot));
}, [
  dailyMode, dailyDate, dailyDifficulty,
  startArea, targetArea, currentPath, guesses, hintsUsed,
  optimalPath, elapsedMs, gameWon, showOptimal, victoryOpen, dailyPar
]);

const [burgerOpen, setBurgerOpen] = useState(false);
const burgerButtonRef = useRef(null);  // anchor for positioning
const [burgerPos, setBurgerPos] = useState({ top: 0, left: 0, width: 224 }); // menu width ~224px

const guessesCount = Math.max(0, currentPath.length - 1);
const parLine = (dailyMode && Number.isFinite(dailyPar))
  ? <>Par: <b>{dailyPar}</b> · <b>{parPhrase(guessesCount, dailyPar)}</b></>
  : null;

  

const parFor = (optimalMoves, diff) =>
  Math.max(1, Math.ceil(optimalMoves * (diff === 'master' ? 1.5 : 1.5)));

useEffect(() => {
  if (!burgerOpen) return;
  // wait a tick for portal render
  const id = requestAnimationFrame(() => {
    const first = document.querySelector('#pp-burger-menu [role="menuitem"]');
    first?.focus?.();
  });
  return () => cancelAnimationFrame(id);
}, [burgerOpen]);

// recompute fixed coordinates when opening / on resize / on scroll
const positionBurgerMenu = useCallback(() => {
  const btn = burgerButtonRef.current;
  if (!btn) return;
  const rect = btn.getBoundingClientRect();
  const gap = 8; // px spacing below the button
  const width = 224; // keep in sync with style below
  const top = rect.bottom + gap;
  const left = Math.max(8, rect.right - width); // protect from going off-screen left
  setBurgerPos({ top, left, width });
}, []);

useEffect(() => {
  if (!burgerOpen) return;
  positionBurgerMenu();
  const onReflow = () => positionBurgerMenu();
  window.addEventListener('resize', onReflow);
  window.addEventListener('scroll', onReflow, true); // true = catch scrolls inside panels too
  return () => {
    window.removeEventListener('resize', onReflow);
    window.removeEventListener('scroll', onReflow, true);
  };
}, [burgerOpen, positionBurgerMenu]);

// close if overlays change
useEffect(() => { setBurgerOpen(false); }, [gameState, showAbout, showTutorial, victoryOpen]);

// --- Daily streak (UTC) ---

const readStreakRecord = React.useCallback((diff) => {
  try { return JSON.parse(localStorage.getItem(STREAK_KEY_V2(diff)) || 'null'); }
  catch { return null; }
}, []);

const saveStreakRecord = React.useCallback((diff, count, lastWinDate) => {
  localStorage.setItem(STREAK_KEY_V2(diff), JSON.stringify({ count, lastWinDate }));
}, []);

const bumpStreakFor = React.useCallback((diff) => {
  const today = (Daily?.todayUTC?.() || todayUTC());
  const rec = readStreakRecord(diff) || { count: 0, lastWinDate: null };

  let next = 1;
  if (rec.lastWinDate === today) {
    next = rec.count;                       // already counted today
  } else if (rec.lastWinDate && daysBetweenUTC(rec.lastWinDate, today) === 1) {
    next = rec.count + 1;                   // extend
  }

  saveStreakRecord(diff, next, today);      // <-- local write

  return next;
}, [readStreakRecord, saveStreakRecord]);

const readStreak = React.useCallback((diff) => {
  const rec = readStreakRecord(diff);
  if (rec && Number.isFinite(+rec.count)) return +rec.count;

  // Legacy fallback for Easy if v2 not present
  if (diff === 'easy') {
    const legacy = loadDailyStreak();
    const n = Number(legacy?.count || 0);
    return Number.isNaN(n) ? 0 : n;
  }
  return 0;
}, [readStreakRecord]);

function getRouteFromHash() {
  const h = (window.location.hash || '').replace(/^#\/?/, '').trim();
  return h || ''; // '' = main app
}
const [route, setRoute] = useState(getRouteFromHash());
useEffect(() => {
  const onHash = () => setRoute(getRouteFromHash());
  window.addEventListener('hashchange', onHash);
  return () => window.removeEventListener('hashchange', onHash);
}, []);
const navigate = useCallback((r) => {
  window.location.hash = r ? `#/${r}` : '#/';
}, []);

const [, setDailyStreak] = useState(() => loadDailyStreak()?.count || 0);

useEffect(() => {
  const s = loadDailyStreak();
  if (!s?.lastWinDate) return;

  const today = todayUTC();
  const gap = daysBetweenUTC(s.lastWinDate, today);

  if (gap > 1) {
    setDailyStreak(0);
    saveDailyStreak(0, s.lastWinDate);
  }
}, [setDailyStreak]); 

React.useEffect(() => {
  // If v2 easy is missing but legacy exists, copy it across
  const v2 = readStreakRecord('easy');
  if (!v2) {
    try {
      const legacy = JSON.parse(localStorage.getItem('pp_daily_streak_v1') || 'null');
      if (legacy && Number(legacy.count) > 0 && legacy.lastWinDate) {
        saveStreakRecord('easy', Number(legacy.count), legacy.lastWinDate);
        setStreaks((s) => ({ ...s, easy: Number(legacy.count) }));
      }
    } catch {}
  }
}, [readStreakRecord, saveStreakRecord]);

// Daily puzzle hash
function bfsAllDistances(start){
  const dist = new Map([[start,0]]), q=[start];
  while (q.length){ const u=q.shift(); const du=dist.get(u);
    for (const v of getNeighbors(u)) if (!dist.has(v)){ dist.set(v, du+1); q.push(v); }
  }
  return dist;
}


const resetDailyFlags = React.useCallback(() => {
  setDailyMode(false);
  setDailyDate(null);
  setDailyDifficulty(null);
  setHintsUsed(0);
  setShowHints(false);
  setDailyGaveUp(false);
  setBetaDailyMode(false);
}, []);


function toggleHints() {
  if (!showHints) {
    if (dailyMode && hintsUsed >= MAX_DAILY_HINTS) {
      alert('No hints left for today.');
      return;
    }
    recordAttemptEvent('hint_opened', {
      from: currentPath[currentPath.length - 1] || null,
      hintNumber: hintsUsed + 1,
    });
    recordAttemptEvent('hint_used', {
      from: currentPath[currentPath.length - 1] || null,
      hintNumber: hintsUsed + 1,
    });
    setHintsUsed(h => h + 1);
  }

  setShowHints(v => !v);
}
const [dailyChoice, setDailyChoice] = useState(null);   // 'easy'|'normal'|'hard'|'master'|null
const [freeChoice,  setFreeChoice]  = useState(null);

const DIFF_LABELS = { easy: 'Easy', normal: 'Normal', hard: 'Hard', master: 'Master', beta: 'Beta Daily' };
const DIFF_DESCRIPTIONS = {
  easy:   'Postcode area outlines and labels are shown. Revisit and undo both allowed.',
  normal: 'Postcode area outlines are shown. Labels hidden on unvisited areas. Revisiting and undo both allowed.',
  hard:   'No outlines or labels are shown. Revisiting is not allowed.',
  master: 'Only start, target and visited areas are shown. Revisit and undo both disabled.',
  beta: 'Experimental Daily Challenge using Normal-style rules and beta features.',
};


const undoLastMove = useCallback(() => {
  if (currentPath.length <= 1 || gameWon) return; // can't undo the start, or after win
  const newPath = currentPath.slice(0, -1);
  setCurrentPath(newPath);
  recordAttemptEvent('move_undone', {
    from: currentPath[currentPath.length - 1],
    to: newPath[newPath.length - 1],
    pathLengthAfter: newPath.length,
    movesAfter: Math.max(0, newPath.length - 1),
  });
  
  setFlashAreas(prev => prev.filter(a => a !== currentPath[currentPath.length - 1]));

  window.gtag?.('event', 'move_undone', {
    difficulty,
    start_postcode: startArea,
    target_postcode: targetArea,
    path_len_after: newPath.length - 1,
    round_id: roundIdRef.current || undefined,
  });
}, [currentPath, gameWon, difficulty, startArea, targetArea]);



useEffect(() => {
  if (masterMode) return; // 🚫 no hotkey in Master

  const onKeyDown = (e) => {
    if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === 'z') {
      e.preventDefault();
      undoLastMove();
    }
  };
  window.addEventListener('keydown', onKeyDown);
  return () => window.removeEventListener('keydown', onKeyDown);
}, [undoLastMove, masterMode]);


const wait = (ms) => new Promise(resolve => window.setTimeout(resolve, ms));

async function playDailyIntroTour(start, target) {
  const token = ++introTourRef.current;
  gameStartRef.current = null;

  if (prefersReducedMotion()) {
    focusStartAndTarget(start, target);
    if (introTourRef.current === token && !gameStartRef.current) {
      gameStartRef.current = performance.now();
    }
    return;
  }

  zoomToArea(start, { duration: 840 });
  await wait(1040);
  if (introTourRef.current !== token || gameStartRef.current) return;

  zoomToArea(target, { duration: 840 });
  await wait(1040);
  if (introTourRef.current !== token || gameStartRef.current) return;

  focusStartAndTarget(start, target);
  await wait(360);
  if (introTourRef.current === token && !gameStartRef.current) {
    gameStartRef.current = performance.now();
    setElapsedMs(0);
  }
}

function startOrResumeDaily(difficulty, { intro = true } = {}) {
  const betaMode = difficulty === 'beta';
  const rulesDifficulty = betaMode ? 'normal' : difficulty;
  const today = Daily.todayUTC();
  const snap = Daily.loadSnapshot(difficulty);

  if (rulesDifficulty === 'easy')   { setShowOutlines(true);  setShowLabels(true);  setMasterMode(false); }
  if (rulesDifficulty === 'normal') { setShowOutlines(true);  setShowLabels(false); setMasterMode(false); }
  if (rulesDifficulty === 'hard')   { setShowOutlines(false); setShowLabels(false); setMasterMode(false); }
  if (rulesDifficulty === 'master') { setShowOutlines(false); setShowLabels(false); setMasterMode(true);  }
  setDifficulty(rulesDifficulty);
  setBetaDailyMode(betaMode);

  if (snap && snap.date === today) {
    const resolvedOptimal =
      Array.isArray(snap.optimalPath) && snap.optimalPath.length
        ? snap.optimalPath
        : Daily.findShortestPathDet(snap.startArea, snap.targetArea, getNeighbors);

    setOptimalPath(resolvedOptimal);
    setDailyPar(
      Number.isFinite(snap.par)
        ? snap.par
        : parForOptimal(Math.max(0, resolvedOptimal.length - 1))
    );

    setDailyMode(true);
    setDailyDate(snap.date);
    setDailyDifficulty(difficulty);
    setHintsUsed(snap.hintsUsed ?? 0);
    setStartArea(snap.startArea);
    setTargetArea(snap.targetArea);
    setCurrentPath(
      Array.isArray(snap.currentPath) && snap.currentPath.length
        ? snap.currentPath
        : [snap.startArea]
    );
    setGuesses(Array.isArray(snap.guesses) ? snap.guesses : []);
    setShowOptimal(!!snap.showOptimal || !!snap.gaveUp || !!snap.roundOver);
    setElapsedMs(snap.elapsedMs || 0);

    const restoredStatus = normalizeStatus(Daily.dailyStatus?.(difficulty));
    const restoredGaveUp = restoredStatus === 'gaveUp' || !!snap.gaveUp || (!!snap.roundOver && !snap.gameWon);
    setDailyGaveUp(restoredGaveUp);

    if (snap.gameWon) {
      setGameWon(true);
      setVictoryOpen(true);
      setGameState('gameWon');
      gameStartRef.current = null;
    } else if (restoredGaveUp) {
      setGameWon(false);
      setShowOptimal(true);
      setVictoryOpen(false);
      setGameState('gameOver');
      gameStartRef.current = null;
    } else {
      setGameWon(false);
      setVictoryOpen(!!snap.victoryOpen);
      setGameState('playing');
      gameStartRef.current = performance.now() - (snap.elapsedMs || 0);
    }

    requestAnimationFrame(() => focusStartAndTarget(snap.startArea, snap.targetArea));
    return;
  }

  setDailyChoice(null);
  setFreeChoice(null);

  const { start, target, path } = Daily.generateTodayDaily(
    difficulty,
    postcodeAreas,
    getNeighbors,
    boundsByDifficulty
  );

  setDailyMode(true);
  setDailyDate(today);
  setDailyDifficulty(difficulty);
  setHintsUsed(0);
  setShowHints(false);
  abandonIfActive(betaMode ? 'beta_daily_start' : 'daily_start');

  setStartArea(start);
  setTargetArea(target);
  setCurrentPath([start]);
  setGuesses([]);
  setGameWon(false);
  setDailyGaveUp(false);
  setOptimalPath(path);
  setDailyPar(parFor(Math.max(0, path.length - 1), rulesDifficulty));
  setGameState('playing');
  gameStartRef.current = intro ? null : performance.now();
  setElapsedMs(0);
  setVictoryOpen(false);
  setShowOptimal(false);

  addVisited([start]);
  recordLifetimeMove({ nextCode: start }, { onPersist });

  if (intro) {
    requestAnimationFrame(() => playDailyIntroTour(start, target));
  } else {
    requestAnimationFrame(() => focusStartAndTarget(start, target));
  }
}


React.useEffect(() => {
  const today = new Date().toISOString().slice(0,10);
  const diffs = ['easy','normal','hard','master'];
  let changed = false;
  for (const d of diffs) {
    const key = `pp_daily_streak_v2_${d}`;
    const rec = JSON.parse(localStorage.getItem(key) || 'null');
    if (rec?.lastWinDate) {
      const diff = Math.round((Date.parse(today + 'T00:00:00Z') - Date.parse(rec.lastWinDate + 'T00:00:00Z'))/86400000);
      if (diff >= 2 && (rec.count || 0) !== 0) {
        localStorage.setItem(key, JSON.stringify({ ...rec, count: 0 }));
        changed = true;
      }
    }
  }
  // if signed in, push immediately
  if (changed && user) onPersist?.(true);
  // eslint-disable-next-line react-hooks/exhaustive-deps
}, []); // run once

useEffect(() => {
  if (!dailyMode || !dailyDate || !dailyDifficulty) return;

  const elapsedSoFar =
    (elapsedMs || 0) +
    (gameStartRef.current ? Math.max(0, performance.now() - gameStartRef.current) : 0);

  const previousDailySnapshot = Daily.loadSnapshot(dailyDifficulty);
  const previousGaveUp =
    previousDailySnapshot?.date === dailyDate &&
    (previousDailySnapshot?.status === 'gave_up' || previousDailySnapshot?.gaveUp === true);
  const resolvedGaveUp = dailyGaveUp || previousGaveUp;

  Daily.saveSnapshot(dailyDifficulty, {
    date: dailyDate,
    difficulty: dailyDifficulty,
    startArea,
    targetArea,
    currentPath,
    guesses,
    hintsUsed,
    optimalPath,
    elapsedMs: Math.floor(elapsedSoFar),
    gameWon,
    gaveUp: resolvedGaveUp,
    roundOver: gameWon || resolvedGaveUp,
    showOptimal: showOptimal || resolvedGaveUp,
    victoryOpen: resolvedGaveUp ? false : victoryOpen,
    par: dailyPar,
    status: resolvedGaveUp ? 'gave_up' : gameWon ? 'won' : 'playing',
    savedAt: new Date().toISOString(),
  });
  onPersist?.();
}, [
  dailyMode, dailyDate, dailyDifficulty,
  startArea, targetArea, currentPath, guesses,
  hintsUsed, optimalPath, elapsedMs, gameWon, dailyGaveUp,
  showOptimal, victoryOpen, dailyPar, onPersist
]);



// ------------------- HELPERS, EFFECTS, CALLBACKS --------------------------
// difficulty
  const startWithDifficulty = (mode) => {
    if (gameState === 'playing' && !gameWon) {
    fireReroll(mode === difficulty ? 'same_difficulty' : 'change_difficulty');
  }
  resetDailyFlags(); 

	setDifficulty(mode);
    if (mode === 'easy') {
      setShowOutlines(true); setShowLabels(true); setMasterMode(false);
    } else if (mode === 'normal') {
      setShowOutlines(true); setShowLabels(false); setMasterMode(false);
    } else if (mode === 'hard') {
      setShowOutlines(false); setShowLabels(false); setMasterMode(false);
    } else if (mode === 'master') {
      setShowOutlines(false); setShowLabels(false); setMasterMode(true);
    }
    startNewGame();
  };
  
const arcPathBridge = (a, b) => arcPath(a, b, 0.12);
const arcPathFerry  = (a, b) => arcPath(a, b, 0.18);

const isRevealed = useCallback(
  (code) =>
    masterMode
      ? code === startArea || code === targetArea || currentPath.includes(code)
      : true,
  [masterMode, startArea, targetArea, currentPath]
);



  //const [streak, setStreak] = useState(() => Number(localStorage.getItem('pp_streak') || 0));
  const gameStartRef = useRef(null);
  const introTourRef = useRef(0);
  
  const isMapInteractive = gameState !== 'menu' && !victoryOpen;

  const formatTime = (ms) => {
    const s = Math.floor(ms / 1000);
    const m = Math.floor(s / 60);
    const r = s % 60;
    return m ? `${m}m ${r}s` : `${r}s`;
  };

useEffect(() => {
  if (!dailyMode) return;
  saveDailySessionSnapshot();
onPersist?.();
}, [
  dailyMode, dailyDate, dailyDifficulty,
  startArea, targetArea, currentPath, guesses,
  hintsUsed, optimalPath, elapsedMs, gameWon,
  showOptimal, victoryOpen, saveDailySessionSnapshot, onPersist
]);

const DIFF_ORDER = ['easy', 'normal', 'hard', 'master'];
const STREAK_MILESTONES = [
  { days: 7, name: 'First-Class Week' },
  { days: 14, name: 'Fortnight Postmark' },
  { days: 30, name: 'Monthly Round' },
  { days: 365, name: 'The Grand Route' },
];


  const { reset, animateTo, getState } = useSvgPan(svgRef, gRef, {
    enabled: isMapInteractive,
    min: MIN_SCALE,
    max: MAX_SCALE,
    onChange: ({ scale }) => setScaleForLabels(scale),
  });

const centerOn = useCallback((code) => {
  const pt = getCenter(code);
  if (!pt) return;

  const current = getState();
  const nextScale = Math.max(current.scale, 2.2);

  const vw = WORLD.width;
  const vh = WORLD.height;
  const svgEl = svgRef.current;
  const svgRect = svgEl?.getBoundingClientRect?.() || null;
  const topRect = topOverlayRef.current?.getBoundingClientRect?.() || null;
  const bottomRect = bottomOverlayRef.current?.getBoundingClientRect?.() || null;
  const topInsetPx = svgRect && topRect ? Math.max(0, topRect.bottom - svgRect.top) : 0;
  const bottomInsetPx = svgRect && bottomRect ? Math.max(0, svgRect.bottom - bottomRect.top) : 0;
  const safeTopFrac = svgRect?.height ? Math.max(0, Math.min(0.45, topInsetPx / svgRect.height)) : 0;
  const safeBottomFrac = svgRect?.height ? Math.max(0, Math.min(0.45, bottomInsetPx / svgRect.height)) : 0;
  const safeHeightFrac = Math.max(0.15, 1 - safeTopFrac - safeBottomFrac);
  const safeCenterFracY = safeTopFrac + safeHeightFrac / 2;
  const viewCx = WORLD.x + vw / 2;
  const viewCy = WORLD.y + vh * safeCenterFracY;

  const tx = viewCx - nextScale * pt.x;
  const ty = viewCy - nextScale * pt.y;

  animateTo(
    { x: tx, y: ty, scale: nextScale },
    { duration: 450 }
  );
}, [getCenter, getState, animateTo]);

 const fitToContent = useCallback((padding = 0.92) => {
   const g = contentRef.current;
   if (!g) return;
   const bbox = g.getBBox();
   if (!bbox || bbox.width === 0 || bbox.height === 0) return;

   const vw = WORLD.width;
   const vh = WORLD.height;
   const fitScale = padding * Math.min(vw / bbox.width, vh / bbox.height);
   const viewCx = WORLD.x + vw / 2;
   const viewCy = WORLD.y + vh / 2;
    const contentCx = bbox.x + bbox.width / 2;
    const contentCy = bbox.y + bbox.height / 2;

    const newTx = viewCx - fitScale * contentCx;
    const newTy = viewCy - fitScale * contentCy;

    reset({ scale: fitScale, x: newTx, y: newTy });
    hasFitRef.current = true;
  }, [reset]);

// ---------- Helpers ----------
const clamp01 = (x) => Math.max(0, Math.min(1, x));
const lerp = (a, b, t) => a + (b - a) * t;

const BBOX_CACHE = new Map();
function getAreaBBoxFromDOM(code) {
  // Prefer data-area, fallback to id
  const el = document.querySelector(`[data-area="${code}"], #area-${code}`);
  if (el && typeof el.getBBox === 'function') {
    try {
      const b = el.getBBox();
      if (b && isFinite(b.x) && isFinite(b.y)) {
        BBOX_CACHE.set(code, b);
        return b;
      }
    } catch {}
  }
  // cached from a previous visit?
  return BBOX_CACHE.get(code) || null;
}

// optional, in case you ever need a fallback bbox around a center
function makeSyntheticBBoxFromCenter(center, size = 700) {
  const half = size / 2;
  return { x: center.x - half, y: center.y - half, width: size, height: size };
}

function getWorldCenter(code) {
  const c = postcodeAreas[code]?.center;
  if (!c) return null;
  return Array.isArray(c) ? { x: c[0], y: c[1] } : c;
}

// ---------- Size-driven zoom (no overrides) ----------
function zoomToArea(code, {
  minScale = MIN_SCALE,
  maxScale = MAX_SCALE,
  duration = 0,
} = {}) {
  // 1) Resolve bbox (prefer real geometry; cached for speed)
  let bbox = getAreaBBoxFromDOM(code);

  // If not found (e.g., not rendered yet), try a synthetic bbox around known center.
  // Size picks a mid value so behavior stays reasonable even without DOM bbox:
  if (!bbox) {
    const c = getWorldCenter(code);
    if (!c) return;
    // Mid-range synthetic size (tuned): 900 world units
    bbox = makeSyntheticBBoxFromCenter(c, 900);
  }

  // 2) Compute relative size r in [0..1] using the *larger* side ratio
  //    (more stable than area on very skinny regions)
  const rx = bbox.width  / WORLD.width;
  const ry = bbox.height / WORLD.height;
  const r  = clamp01(Math.max(rx, ry));



  

  // 3) Size-adaptive knobs derived from r (smooth power curves)
  //    - Tiny regions (r → 0): zoom in more (small minFrac, tight pad, no relax)
  //    - Huge regions (r → 1): zoom out a bit (larger minFrac, more pad, some relax)
const minFrac = lerp(0.25, 0.18, Math.pow(r, 0.55)); // tiny areas zoom in more
const pad     = lerp(0.06,  0.24, Math.pow(r, 0.80)); // more padding for big areas
const relax   = lerp(1.00,  1.40, Math.pow(r, 0.70)); // gentle zoom-out for big areas

  
  // 4) Expand bbox with min region + padding + relax (WORLD-based)
  const cx = bbox.x + bbox.width  / 2;
  const cy = bbox.y + bbox.height / 2;

  const spanX = Math.max(bbox.width,  WORLD.width  * minFrac) * relax;
  const spanY = Math.max(bbox.height, WORLD.height * minFrac) * relax;

  const w = spanX * (1 + pad * 2);
  const h = spanY * (1 + pad * 2);

  const svgEl = svgRef.current;
  const svgRect = svgEl?.getBoundingClientRect?.() || null;
  const topRect = topOverlayRef.current?.getBoundingClientRect?.() || null;
  const bottomRect = bottomOverlayRef.current?.getBoundingClientRect?.() || null;
  const topInsetPx = svgRect && topRect ? Math.max(0, topRect.bottom - svgRect.top) : 0;
  const bottomInsetPx = svgRect && bottomRect ? Math.max(0, svgRect.bottom - bottomRect.top) : 0;
  const safeTopFrac = svgRect?.height ? Math.max(0, Math.min(0.45, topInsetPx / svgRect.height)) : 0;
  const safeBottomFrac = svgRect?.height ? Math.max(0, Math.min(0.45, bottomInsetPx / svgRect.height)) : 0;
  const safeHeightFrac = Math.max(0.15, 1 - safeTopFrac - safeBottomFrac);

  // 5) Keep the original zoom feel, but avoid choosing a zoom that clips the
  // target area behind mobile overlays.
  const fullFitScale = Math.min(WORLD.width / w, WORLD.height / h);
  const safeFitScale = Math.min(WORLD.width / w, (WORLD.height * safeHeightFrac) / h);
  const hasVerticalOverlay = safeTopFrac > 0 || safeBottomFrac > 0;
  const visibleFitScale = hasVerticalOverlay ? safeFitScale : fullFitScale;
  let s = Math.min(fullFitScale, visibleFitScale * 1.5);
  s = Math.max(minScale, Math.min(maxScale, s));

  // 6) Translate so area center lands in the visible safe area.
  const safeCenterFracY = safeTopFrac + safeHeightFrac / 2;
  const viewCx = WORLD.x + WORLD.width  / 2;
  const viewCy = WORLD.y + WORLD.height * safeCenterFracY;
  const tx = viewCx - s * cx;
  const ty = viewCy - s * cy;

  // 7) Apply via your useSvgPan
  if (duration > 0) {
  animateTo({ scale: s, x: tx, y: ty }, { duration });
} else {
  reset({ scale: s, x: tx, y: ty });
}
}



function parInfo({ moves, optimal, parMoves }) {
  const par = Number.isFinite(parMoves)
    ? parMoves
    : Math.max(1, Math.ceil(optimal * 1.5));

  const delta = moves - par;
  const label = delta < 0
    ? `${Math.abs(delta)} under par`
    : delta === 0
      ? 'On par'
      : `${delta} over par`;

  return { par, delta, label };
}
// Emoji for each step type in the final route
const MOVE_ICON = {
  land: '\u{1F7E9}',
  bridge: '\u{1F7E6}',
  ferry: '\u{1F7EA}',
};

const SHARE_DOT = '\u00B7';
const SHARE_ARROW = '\u2192';

const buildShareText = () => {
  const moves = Math.max(0, currentPath.length - 1);
  const optimal = Math.max(0, (optimalPath?.length || 1) - 1);
  const { par, label } = parInfo({ moves, optimal });
  const time = elapsedMs ? formatTime(elapsedMs) : null;
  const cleanRun = Number(hintsUsed || 0) === 0;
  const assistedLabel = cleanRun ? 'Clean run' : `Assisted (${hintsUsed} hint${hintsUsed === 1 ? '' : 's'})`;

  let routeTiles = '';
  if (currentPath && currentPath.length > 1) {
    for (let i = 1; i < currentPath.length; i += 1) {
      const prev = currentPath[i - 1];
      const curr = currentPath[i];
      const t = edgeType(prev, curr);
      routeTiles += MOVE_ICON[t] ?? '\u2B1C';
    }
  }

  const difficultyLabel = DIFF_LABELS[dailyDifficulty || difficulty] || dailyDifficulty || difficulty;
  const header = dailyMode
    ? `Postcode Pursuit Daily ${SHARE_DOT} ${difficultyLabel} ${SHARE_DOT} ${dailyDate}`
    : `Postcode Pursuit ${SHARE_DOT} ${DIFF_LABELS[difficulty] || difficulty}`;

  const lines = [header, ''];

  if (!dailyMode && startArea && targetArea) {
    lines.push(`${startArea} ${SHARE_ARROW} ${targetArea}`, '');
  }

  lines.push(gameWon ? `Solved in ${moves} moves` : `Gave up after ${moves} moves`);
  if (Number.isFinite(par)) lines.push(`Par: ${par} ${SHARE_DOT} Optimal: ${optimal}`);
  if (label) lines.push(label);
  lines.push(time ? `${assistedLabel} ${SHARE_DOT} ${time}` : assistedLabel);

  if (dailyMode && dailyDifficulty && !betaDailyMode) {
    const streak = (streaks?.[dailyDifficulty] ?? readStreak?.(dailyDifficulty) ?? 0);
    if (streak > 0) lines.push(`${DIFF_LABELS[dailyDifficulty]} streak: ${streak}`);
  }

  if (routeTiles) {
    lines.push('', routeTiles);
  }

  lines.push('postcode-pursuit.co.uk');
  return lines.join('\n');
};
  const linkPaint = (type) => {
  switch (type) {
    case "ferry":
      return { stroke: "#0284c7", width: 12, dash: "40 28" }; // cyan-ish, dashed
    case "tunnel":
      return { stroke: "#adb0b6ff", width: 3, dash: "5 1" }; // slate-600, dotted-ish
    case "bridge":
    default:
      return { stroke: "#ffffffff", width: 3, dash: "" };      // slate-600, solid
  }
};

const handleInputSubmit = (inputElement) => {
  const val = inputElement.value.toUpperCase().trim();
  if (!val) return;

  const currentLocation = currentPath[currentPath.length - 1];
  const isKnownArea = !!postcodeAreas[val];
  const isValidMove = getNeighbors(currentLocation).includes(val);
  const alreadyVisited = currentPath.includes(val);
  const revisitAllowed = difficulty === 'easy' || difficulty === 'normal';
  const allowedMove = isValidMove && (!alreadyVisited || revisitAllowed);

  makeGuess(val);
  inputElement.value = '';
  setSelectorEmpty(true);

  if (!isKnownArea) return;

  requestAnimationFrame(() => {
    zoomToArea(val, {
      duration: allowedMove ? 0 : 250,
    });

    if (!allowedMove) {
      window.setTimeout(() => {
        zoomToArea(currentLocation, {
          duration: 450,
        });
      }, 700);
    }
  });
};
  
  const inputRef = useRef(null);

  const focusPostcodeInput = useCallback(() => {
    if (typeof window === 'undefined') return;
    window.requestAnimationFrame(() => {
      const el = inputRef.current;
      if (!el) return;
      try {
        el.focus({ preventScroll: true });
      } catch {
        el.focus();
      }
      if (typeof el.select === 'function') el.select();
    });
  }, []);

  const shareResult = async () => {
    const text = buildShareText();
    try {
      if (navigator.share) await navigator.share({ text });
      else {
        await navigator.clipboard.writeText(text);
        alert('Result copied to clipboard!');
      }
    } catch {/* ignore */}
  };
  
   const bridgeAdj = React.useMemo(() => {
  const m = new Map();
  (bridgeLinks ?? []).forEach(({ a, b }) => {
    if (!postcodeAreas[a] || !postcodeAreas[b]) return;
    if (!m.has(a)) m.set(a, new Set());
    if (!m.has(b)) m.set(b, new Set());
    m.get(a).add(b);
    m.get(b).add(a);
  });
  return m;
}, []);

const ferryAdj = React.useMemo(() => {
  const m = new Map();
  (ferryLinks ?? []).forEach(({ a, b }) => {
    if (!postcodeAreas[a] || !postcodeAreas[b]) return;
    if (!m.has(a)) m.set(a, new Set());
    if (!m.has(b)) m.set(b, new Set());
    m.get(a).add(b);
    m.get(b).add(a);
  });
  return m;
}, []);

// Big list for the selection box: real area codes + plausible decoys
const allPostcodeOptions = React.useMemo(
  () => Object.keys(postcodeAreas).sort((a, b) => a.localeCompare(b)),
  []
);

// ----- Label visibility by zoom (future-proof layers) -----
const LABEL_LAYERS = [
  { minScale: 7.5, codes: ['WC', 'EC'] },                 // super-dense core
  { minScale: 4.5, codes: ['E', 'N', 'NW', 'W'] },        // next ring
  { minScale: 3.5, codes: ['SE', 'SW', 'IG', 'EN'] }, 
  // Add more as needed, e.g.:
  // { minScale: 3.5, codes: ['SE','SW'] },
  // { minScale: 3,   codes: ['IG','HA','EN','RM','UB','TW','KT','BR','CR','DA','SM'] },
];

const LABEL_MIN_SCALE = (() => {
  const m = new Map();
  for (const { minScale, codes } of LABEL_LAYERS) {
    for (const c of codes) m.set(c, minScale);
  }
  return m;
})();

function labelVisibleAtScale(code, scale) {
  const need = LABEL_MIN_SCALE.get(code);
  if (need == null) return true;       // not in a dense layer → always visible
  return scale >= need;
}

const forceUppercase = useCallback((e) => {
  const el = e.currentTarget;
  const { selectionStart, selectionEnd } = el;
  const up = el.value.toUpperCase();
  if (el.value !== up) {
    el.value = up;
    // preserve caret position
    el.setSelectionRange(selectionStart, selectionEnd);
  }
}, []);

// state (near your other state)
const [selectorEmpty, setSelectorEmpty] = useState(true);
const shouldPulse =
  gameState === 'playing' &&
  !gameWon &&
  !showTutorial &&
  !showAbout &&
  !victoryOpen &&
  selectorEmpty;
// keep your forceUppercase, then wrap it:
const handleSelectorInput = useCallback((e) => {
  forceUppercase(e);
  setSelectorEmpty(e.currentTarget.value.trim() === "");
}, [forceUppercase]);

const [showNudge, setShowNudge] = useState(false);
const nudgeDismissedRef = useRef(false);
const NUDGE_DISMISSED_KEY = 'pp_nudge_dismissed';

const hasCompletedAnyGame = React.useMemo(() => {
  try {
    const history = readJSON(GAME_HISTORY_KEY, { games: [] });
    return (history.games || []).some(g => g?.won === true);
  } catch {
    return false;
  }
}, []);

useEffect(() => {
  if (!consentResolved) return;

  const nudgeDismissedPersistently = localStorage.getItem(NUDGE_DISMISSED_KEY) === 'true';
  const atStart = gameState === 'playing' && currentPath.length === 1;

  if (!atStart || nudgeDismissedRef.current || nudgeDismissedPersistently || hasCompletedAnyGame) {
    setShowNudge(false);
    return;
  }

  const id = window.setTimeout(() => setShowNudge(true), 20000);
  return () => window.clearTimeout(id);
}, [consentResolved, gameState, currentPath.length, hasCompletedAnyGame]);

const dismissNudge = () => {
  nudgeDismissedRef.current = true; // don’t show again this round
  localStorage.setItem(NUDGE_DISMISSED_KEY, 'true');
  setShowNudge(false);
  focusPostcodeInput();
};

const tallyEdgeUsage = useCallback((path) => {
  let ferryCount = 0, bridgeCount = 0;
  for (let i = 1; i < path.length; i++) {
    const a = path[i - 1], b = path[i];
    if (ferryAdj.get(a)?.has(b)) ferryCount++;
    else if (bridgeAdj.get(a)?.has(b)) bridgeCount++;
  }
  return { ferryCount, bridgeCount };
}, [ferryAdj, bridgeAdj]);


useEffect(() => {
  console.log('toast check', { consentResolved, gameState, len: currentPath.length, dismissed: nudgeDismissedRef.current });
}, [consentResolved, gameState, currentPath.length]);

useEffect(() => {
  console.log('showNudge ->', showNudge);
}, [showNudge]);

// listen for consent completion from ConsentManager
useEffect(() => {
  const onResolved = () => setConsentResolved(true);
  window.addEventListener('pp:consent:resolved', onResolved);
  return () => window.removeEventListener('pp:consent:resolved', onResolved);
}, []);

// only show the tutorial after consent is resolved
useEffect(() => {
  if (!consentResolved) return;
  const done = localStorage.getItem(ONBOARDING_KEY) === 'true';
  if (!done) setShowTutorial(true);
}, [consentResolved]);
useEffect(() => {
  const setGameViewportHeight = () => {
    const height = window.visualViewport?.height || window.innerHeight;
    if (height) {
      document.documentElement.style.setProperty('--pp-game-vh', `${height}px`);
    }
  };

  setGameViewportHeight();
  window.addEventListener('resize', setGameViewportHeight);
  window.addEventListener('orientationchange', setGameViewportHeight);
  window.visualViewport?.addEventListener('resize', setGameViewportHeight);
  window.visualViewport?.addEventListener('scroll', setGameViewportHeight);

  return () => {
    window.removeEventListener('resize', setGameViewportHeight);
    window.removeEventListener('orientationchange', setGameViewportHeight);
    window.visualViewport?.removeEventListener('resize', setGameViewportHeight);
    window.visualViewport?.removeEventListener('scroll', setGameViewportHeight);
  };
}, []);


// Menu choosers
const [showDailyChooser, setShowDailyChooser] = useState(false);
const [showFreePlayChooser, setShowFreePlayChooser] = useState(false);

// simple appear animation state
/* const [dailyAnim, setDailyAnim] = useState("opacity-0 -translate-y-2 scale-95");
useEffect(() => {
  if (!showDailyChooser) return;
  const id = requestAnimationFrame(() =>
    setDailyAnim("opacity-100 translate-y-0 scale-100")
  );
  return () => cancelAnimationFrame(id);
}, [showDailyChooser]); */


// Close chooser(s) with Escape
useEffect(() => {
  if (!showDailyChooser && !showFreePlayChooser) return;
  const onKey = (e) => { if (e.key === 'Escape') { setShowDailyChooser(false); setShowFreePlayChooser(false); } };
  window.addEventListener('keydown', onKey);
  return () => window.removeEventListener('keydown', onKey);
}, [showDailyChooser, showFreePlayChooser]);


// simple appear animation for Free Play
const [freeAnim, setFreeAnim] = useState("opacity-0 -translate-y-2 scale-95");
useEffect(() => {
  if (!showFreePlayChooser) return;
  const id = requestAnimationFrame(() =>
    setFreeAnim("opacity-100 translate-y-0 scale-100")
  );
  return () => cancelAnimationFrame(id);
}, [showFreePlayChooser]);

const [menuAnimClass, setMenuAnimClass] = useState("opacity-0 -translate-y-1 scale-95");

useEffect(() => {
  if (!burgerOpen) return;
  // let the element paint, then animate in
  const id = requestAnimationFrame(() =>
    setMenuAnimClass("opacity-100 translate-y-0 scale-100")
  );
  return () => cancelAnimationFrame(id);
}, [burgerOpen]);


// --- unified neighbors (land + ferries + bridges) ---
const getNeighbors = React.useCallback((code) => {
  const set = new Set(postcodeAreas[code]?.neighbors ?? []);

  const ferries = ferryAdj.get(code);
  if (ferries) ferries.forEach((n) => set.add(n));

  const bridges = bridgeAdj.get(code);
  if (bridges) bridges.forEach((n) => set.add(n));

  return Array.from(set);
}, [ferryAdj, bridgeAdj]);

  // ---------- ICONS & PULSES ----------
  const attachPathRef = (id) => (el) => {
    if (!el) return;
    const b = el.getBBox();
    centroidsRef.current[id] = { x: b.x + b.width / 2, y: b.y + b.height / 2 };
  };
/* function bfsAllDistances(start) {
  const dist = new Map([[start, 0]]);
  const q = [start];
  while (q.length) {
    const u = q.shift();
    const du = dist.get(u);
    for (const v of getNeighbors(u)) {
      if (!dist.has(v)) {
        dist.set(v, du + 1);
        q.push(v);
      }
    }
  }
  return dist; // Map<areaCode, steps>
} */


  

  // Return a quadratic curve string between area centres, with a slight bend
function arcPath(a, b, bend = 0.18) {
  const A = getCenter(a), B = getCenter(b);
  if (!A || !B) return null;
  const mx = (A.x + B.x) / 2, my = (A.y + B.y) / 2;
  const dx = B.x - A.x, dy = B.y - A.y;
  const len = Math.hypot(dx, dy) || 1;
  const nx = -dy / len, ny = dx / len; // unit normal
  const cx = mx + nx * bend * len;
  const cy = my + ny * bend * len;
  return `M ${A.x} ${A.y} Q ${cx} ${cy} ${B.x} ${B.y}`;
}

function bfsDistance(start, target) {
  if (!start || !target || start === target) return 0;
  const q = [[start, 0]];
  const seen = new Set([start]);
  while (q.length) {
    const [node, d] = q.shift();
    for (const n of getNeighbors(node)) {
      if (seen.has(n)) continue;
      if (n === target) return d + 1;
      seen.add(n);
      q.push([n, d + 1]);
    }
  }
  return Infinity;
}

function fireReroll(reason = 'new_game_button') {
  if (!isActiveRound()) return;
  const elapsedSec =
    gameStartRef.current ? Math.round((performance.now() - gameStartRef.current) / 1000) : null;
  const pathLen = optimalPath?.length ? optimalPath.length - 1 : null;

  window.gtag?.('event', 'game_rerolled', {
    difficulty,
    path_length: pathLen,
    elapsed_sec: elapsedSec,
    reason,                  // 'new_game_button' | 'change_difficulty' | etc.
    round_id: roundIdRef.current,
  });
}



const [errorToast, setErrorToast] = useState('');

const showError = useCallback((msg) => {
  setErrorToast(msg);
  try { 
    if ('vibrate' in navigator) navigator.vibrate(40); 
  } catch {}
}, []);



const [giveUpOpen, setGiveUpOpen] = useState(false);

const giveUpNow = useCallback(() => {
  // stop the clock
  const end = performance.now();
  const ms = gameStartRef.current ? Math.max(0, end - gameStartRef.current) : 0;
  setElapsedMs(ms);

  // record a LOSS in history (mirrors your win event)
  const advancingGuesses = guesses.filter(g => g.valid && !g.alreadyVisited);
  const ferryCount   = advancingGuesses.filter(g => g.viaFerry).length;
  const bridgeCount  = advancingGuesses.filter(g => g.viaBridge).length;
  const optimalMoves = Math.max(0, (optimalPath?.length || 1) - 1);

  const event = {
    id: (crypto?.randomUUID?.() || `${Date.now()}-${Math.random()}`),
    dateISO: new Date().toISOString(),
    mode: dailyMode ? 'daily' : 'free',
    difficulty,
    won: false,
    moves: Math.max(0, currentPath.length - 1),
    durationMs: ms,
    usedFerry: ferryCount > 0,
    usedBridge: bridgeCount > 0,
    ferryCount,
    bridgeCount,
    optimalMoves,
    hintsUsed,
    pathUsed: currentPath.slice(),
    startArea,
    target_postcode: targetArea,
  };
  addGameToHistory(event, { onPersist: () => onPersist(true) });

  window.gtag?.('event', 'game_gave_up', {
    difficulty,
    start_postcode: startArea,
    target_postcode: targetArea,
    guesses: Math.max(0, currentPath.length - 1),
    time_ms: ms,
    round_id: roundIdRef.current || undefined,
  });

  const attemptSummary = finishAttempt('gave_up', {
    moves: Math.max(0, currentPath.length - 1),
    par: dailyMode && Number.isFinite(dailyPar) ? dailyPar : optimalMoves,
    optimalMoves,
    durationMs: ms,
    hintsUsed,
    pathUsed: currentPath.slice(),
    inputStyle: analyticsInputStyle,
    mapStyle,
  });
  syncAttemptSummary(attemptSummary);

  setGiveUpOpen(false);
  setVictoryOpen(false);
  setShowHints(false);
  gameStartRef.current = null;

  if (dailyMode && dailyDifficulty && dailyDate) {
    setGameWon(false);
    setDailyGaveUp(true);
    setShowOptimal(true);

    Daily.saveSnapshot(dailyDifficulty, {
      date: dailyDate,
      difficulty: dailyDifficulty,
      startArea,
      targetArea,
      currentPath,
      guesses,
      hintsUsed,
      optimalPath,
      elapsedMs: Math.floor(ms),
      gameWon: false,
      gaveUp: true,
      roundOver: true,
      showOptimal: true,
      victoryOpen: false,
      par: dailyPar,
      status: 'gave_up',
      savedAt: new Date().toISOString(),
    });
    onPersist?.();


    
    setGameState('dailyLost');
    roundIdRef.current = null;
    return;
  }

  setGameState('menu');
  roundIdRef.current = null;
}, [
  guesses, optimalPath, currentPath, startArea, targetArea,
  dailyMode, dailyDifficulty, dailyDate, dailyPar, hintsUsed, difficulty, onPersist,
  analyticsInputStyle, mapStyle
]);

const topOverlayRef = useRef(null);
const bottomOverlayRef = useRef(null);

  // ---------- STATE CLASSES (Option A) ----------
const focusStartAndTarget = React.useCallback((startCode, targetCode, pad = 0.2) => {
  const A = getCenter(startCode);
  const B = getCenter(targetCode);
  const svgEl = svgRef.current;

  if (!A || !B || !svgEl) return;

  const svgRect = svgEl.getBoundingClientRect();
  if (!svgRect.height || !svgRect.width) return;

  const topRect = topOverlayRef.current?.getBoundingClientRect?.() || null;
  const bottomRect = bottomOverlayRef.current?.getBoundingClientRect?.() || null;

  const topInsetPx = topRect ? Math.max(0, topRect.bottom - svgRect.top) : 0;
  const bottomInsetPx = bottomRect ? Math.max(0, svgRect.bottom - bottomRect.top) : 0;

  const safeTopFrac = Math.max(0, Math.min(0.45, topInsetPx / svgRect.height));
  const safeBottomFrac = Math.max(0, Math.min(0.45, bottomInsetPx / svgRect.height));
  const safeHeightFrac = Math.max(0.15, 1 - safeTopFrac - safeBottomFrac);

  const minX = Math.min(A.x, B.x);
  const maxX = Math.max(A.x, B.x);
  const minY = Math.min(A.y, B.y);
  const maxY = Math.max(A.y, B.y);

  const MIN_FRACTION = 0.18;
  const spanX = Math.max(maxX - minX, WORLD.width * MIN_FRACTION);
  const spanY = Math.max(maxY - minY, WORLD.height * MIN_FRACTION);

  const padX = pad;
  const padY = pad;

  const w = spanX * (1 + padX * 2);
  const h = spanY * (1 + padY * 2);

  const cx = (A.x + B.x) / 2;
  const cy = (A.y + B.y) / 2;

  const vw = WORLD.width;
  const vh = WORLD.height;

  const fitScaleX = vw / w;
  const fitScaleY = (vh * safeHeightFrac) / h;

  let s = Math.min(fitScaleX, fitScaleY);
  s = Math.max(MIN_SCALE, Math.min(MAX_SCALE, s));

  const safeCenterFracY = safeTopFrac + safeHeightFrac / 2;
  const viewCx = WORLD.x + vw / 2;
  const viewCy = WORLD.y + vh * safeCenterFracY;

  const tx = viewCx - s * cx;
  const ty = viewCy - s * cy;

  reset({ scale: s, x: tx, y: ty });

  hasFitRef.current = true;
  didAutoFitRef.current = true;
}, [reset, getCenter]);




const COLORS = mapStyle === 'night'
  ? {
      baseFill:    '#162533',
      baseStroke:  '#d7e6f3',
      startFill:   '#14b8a6',
      startStroke: '#99f6e4',
      currentFill: '#60a5fa',
      currentStroke:'#dbeafe',
      visitedFill: '#22c55e',
      visitedStroke:'#bbf7d0',
      targetFill:  '#fbbf24',
      targetStroke:'#fde68a',
    }
  : mapStyle === 'contrast'
    ? {
      baseFill:    '#fff7ed',
      baseStroke:  '#111827',
      startFill:   '#005f73',
      startStroke: '#003844',
      currentFill: '#1d4ed8',
      currentStroke:'#FFFFFF',
      visitedFill: '#047857',
      visitedStroke:'#064e3b',
      targetFill:  '#d97706',
      targetStroke:'#7c2d12',
    }
    : colorblindFriendly
      ? {
      baseFill:    '#ecded6ff',
      baseStroke:  '#2e3744ff',
      startFill:   '#0072B2',
      startStroke: '#005C8F',
      currentFill: '#56B4E9',
      currentStroke:'#FFFFFF',
      visitedFill: '#009E73',
      visitedStroke:'#005F46',
      targetFill:  '#E69F00',
      targetStroke:'#9A6700',
      }
      : {
      baseFill:    '#ecded6ff',
      baseStroke:  '#2e3744ff',
      startFill:   '#1a6e65ff',
      startStroke: '#0F766E',
      currentFill: '#2563EB',
      currentStroke:'#FFFFFF',
      visitedFill: '#04bd32ff',
      visitedStroke:'#64748B',
      targetFill:  '#F59E0B',
      targetStroke:'#92400E',
    };

  const currentArea = currentPath[currentPath.length - 1] || null;
 // const visitedSet  = useMemo(() => new Set(currentPath), [currentPath]);
 
const getAreaStyle = (code) => {
  const isStart   = code === startArea;
  const isTarget  = code === targetArea;
  const isCurrent = currentArea && code === currentArea && !isStart && !roundResolved;
  const isVisited = currentPath.includes(code);
  const isFlashing = flashAreas.includes(code);

  if (isFlashing) {
    return {
      fill: 'rgba(165, 7, 7, 0.18)',
      stroke: '#e3e637ff',
      strokeWidth: 5,
      strokeDasharray: '6 4',
    };
  }

  const revealedInMaster = isStart || isTarget || isVisited || isCurrent;
  if (masterMode && !revealedInMaster) {
    return { fill: 'transparent', stroke: 'none', strokeWidth: 0 };
  }
  
  // 🔴 Invalid/duplicate guess flash overrides everything for 400ms
if (isFlashing) {
  return {
    fill: 'transparent',
    stroke: '#e3e637ff',
    strokeWidth: 6,
    strokeDasharray: '8 5',
  };
}

  // ---- normal coloring ----
  let fill   = COLORS.baseFill;
  let stroke = COLORS.baseStroke;
  let dash   = null;

  if (isTarget) {
    fill = COLORS.targetFill;  stroke = COLORS.targetStroke;
  } else if (isStart) {
    fill = COLORS.startFill;   stroke = COLORS.startStroke;
  } else if (isCurrent) {
    fill = COLORS.currentFill; stroke = COLORS.currentStroke;
  } else if (isVisited) {
    fill = COLORS.visitedFill; stroke = COLORS.visitedStroke; dash = '3 3';
  }


  // Visited areas force outlines ON regardless of toggle/mode (your a11y rule)
  const outlinesOn = showOutlines || isVisited;
  
  

  return {
    fill,
    stroke: outlinesOn ? (isVisited ? COLORS.visitedStroke : stroke) : 'none',
    strokeWidth: outlinesOn ? 1.25 : 0,
    ...(outlinesOn && dash ? { strokeDasharray: dash } : {}),
    ...(outlinesOn ? {} : { shapeRendering: 'crispEdges' }),
  };
};
// pick a single example neighbour for the nudge
const [exampleNeighbor, setExampleNeighbor] = useState('');

useEffect(() => {
  if (gameState !== 'playing' || currentPath.length === 0) {
    setExampleNeighbor('');
    return;
  }
  const current = currentPath[currentPath.length - 1];
  // valid neighbours you haven’t visited yet
  const candidates = getNeighbors(current).filter(n => !currentPath.includes(n));

  if (candidates.length) {
    // deterministic-ish pick so it doesn’t flicker every render
    const seed =
      (current?.charCodeAt?.(0) || 0) +
      (targetArea?.charCodeAt?.(0) || 0) +
      (targetArea?.charCodeAt?.(1) || 0);
    const idx = seed % candidates.length;
    setExampleNeighbor(candidates[idx]);
  } else {
    setExampleNeighbor('');
  }
}, [gameState, currentPath, getNeighbors, targetArea]);

// --- Achievements setup

const [statsVersion, setStatsVersion] = React.useState(0);

const resetAllStats = React.useCallback(({ alsoResetStreaks = true } = {}) => {
  const cleared = emptySnapshot();

  if (!alsoResetStreaks) {
    cleared.streaks = getLocalSnapshot().streaks;
  }

  writeLocalSnapshot(cleared);
  localStorage.removeItem(VISITED_KEY);
  localStorage.removeItem(USED_FERRIES_KEY);
  localStorage.removeItem(USED_BRIDGES_KEY);
  localStorage.removeItem('pp_daily_streak_v1');

  for (const d of DIFFS) {
    localStorage.removeItem(dailySessionKey(d));
  }

  clearAchievementToasts();
  setStreaks(cleared.streaks);
  setStatsVersion(v => v + 1);

  if (user) {
    overwriteNow(cleared);
  }
}, [user, overwriteNow, clearAchievementToasts]);


function computeStats(){
  const db = readJSON(GAME_HISTORY_KEY, { games: [] });
  const g = db.games;
  const wins = g.filter(x=>x.won);

  // helper: average (moves - par) where par = ceil(optimal*1.5)
  const avgVsPar = (list) => {
    const deltas = [];
    for (const x of list) {
      if (!x.won) continue;
      const opt = Number(x.optimalMoves);
      const mov = Math.max(0, Number(x.moves || 0));
      if (!Number.isFinite(opt)) continue;
      const par = Math.ceil(Math.max(0, opt) * 1.5);
      deltas.push(mov - par);
    }
    if (!deltas.length) return null;
    const mean = deltas.reduce((a,b)=>a+b,0) / deltas.length;
    return Number(mean.toFixed(1));  // e.g. -1.2, +0.7
  };

  const DIFFS = ['easy','normal','hard','master'];
  const byDiff = DIFFS.map(d => {
    const list = g.filter(x=>x.difficulty===d);
    const games = list.length;
    const w = list.filter(x=>x.won).length;
    return {
      difficulty: d,
      games,
      wins: w,
      avgVsPar: avgVsPar(list),  // may be null if no qualifying wins
    };
  });

  return {
    totalGames: g.length,
    winRate: g.length ? Math.round(wins.length / g.length * 100) : 0,
    avgMoves: wins.length ? (wins.reduce((s,x)=>s+x.moves,0)/wins.length).toFixed(1) : '—',
    bestTime: wins.length ? Math.min(...wins.map(x=>x.durationMs)) : null,
    avgVsPar: avgVsPar(g), // overall
    byDiff,
    winCount: wins.length,
  };
}





const [leaveConfirmOpen, setLeaveConfirmOpen] = useState(false);


  // ---------- Victory modal timing ----------
const finishGame = useCallback((finalPath) => {
  const path = Array.isArray(finalPath) && finalPath.length ? finalPath : currentPath;

  setGameWon(true);
  setShowOptimal(true);
  addVisited([targetArea], postcodeAreas);
 const metaNew = checkAndUnlockMetaAchievements(difficulty, postcodeAreas, ferryLinks, bridgeLinks);
  if (metaNew?.length) enqueueAchievementBatch(metaNew);

  setGameState('gameWon');
  const end = performance.now();
  const ms = gameStartRef.current ? Math.max(0, end - gameStartRef.current) : 0;
  setElapsedMs(ms);

  const { ferryCount, bridgeCount } = tallyEdgeUsage(path);
  const optimalMoves = Math.max(0, (optimalPath?.length || 1) - 1);

const moves = Math.max(0, path.length - 1);
const perfect = Number.isFinite(optimalMoves) && moves === optimalMoves;


const event = {
  id: (crypto?.randomUUID?.() || `${Date.now()}-${Math.random()}`),
  dateISO: new Date().toISOString(),
  mode: dailyMode ? 'daily' : 'free',
  difficulty,
  won: true,
  moves,
  durationMs: ms,
  usedFerry: ferryCount > 0,
  usedBridge: bridgeCount > 0,
  ferryCount,
  bridgeCount,
  optimalMoves,
  hintsUsed,
  perfect,
  pathUsed: path.slice(),
  startArea,
  endArea: targetArea,
};

addGameToHistory(event);

if (dailyMode && dailyDifficulty && !betaDailyMode) {
  const rec = bumpStreakFor(dailyDifficulty);
  setStreaks(s => ({ ...s, [dailyDifficulty]: rec.count ?? rec }));

  const streakNew = unlockStreaksFor(dailyDifficulty);
  if (streakNew.length) enqueueAchievementBatch(streakNew);
}


const unlocked = evaluateAndUnlockAchievements(event);
if (unlocked.length) {
  enqueueAchievementBatch(unlocked);
  logAchievementsToGA(unlocked, {
    difficulty,
    dailyMode,
    ferryCount: event.ferryCount,
    bridgeCount: event.bridgeCount,
  }
)

;
}


if (unlocked?.length && window.gtag) {
  for (const a of unlocked) {
    window.gtag('event', 'achievement_unlocked', {
      achievement_id: a.id,
      tier: a.tier,                // bronze | silver | gold | legendary
      difficulty,                  // current game difficulty
      mode: dailyMode ? 'daily' : 'free',
      round_id: roundIdRef.current || undefined,
    });
  }
}



  // ---- Analytics ----
if (window.gtag) {
window.gtag?.('event', 'game_finished', {
  round_id: roundIdRef.current,
  won: 1,
  difficulty,
  mode: dailyMode ? 'daily' : 'free',
  daily_mode: dailyMode ? 1 : 0,
  start_postcode: startArea,
  target_postcode: targetArea,
  moves,
  optimal_moves: optimalMoves,
  perfect: perfect ? 1 : 0,
  time_ms: ms,
  ferry_count: ferryCount,
  bridge_count: bridgeCount,
  hints_used: hintsUsed,
});
  }

  const attemptSummary = finishAttempt('won', {
    moves,
    par: dailyMode && Number.isFinite(dailyPar) ? dailyPar : optimalMoves,
    optimalMoves,
    durationMs: ms,
    hintsUsed,
    pathUsed: path.slice(),
    inputStyle: analyticsInputStyle,
    mapStyle,
  });
  syncAttemptSummary(attemptSummary);

  onPersist(true);
  setVictoryOpen(true);
}, [
  currentPath, optimalPath,
  difficulty, startArea, targetArea,
  dailyMode, dailyDifficulty,
  bumpStreakFor, tallyEdgeUsage, onPersist, enqueueAchievementBatch,hintsUsed, betaDailyMode,
  dailyPar, analyticsInputStyle, mapStyle
]);

useEffect(() => {
  if (gameState !== 'menu' && !hasFitRef.current) {
    requestAnimationFrame(() => fitToContent());
  }
}, [gameState, fitToContent]);

// Lock page scroll only while the map is active (no modals)
useEffect(() => {
  const prevHtml = document.documentElement.style.overflow;
  const prevBody = document.body.style.overflow;

  const overlayOpen =
  showDailyChooser ||
  showFreePlayChooser ||
  victoryOpen ||
  giveUpOpen ||
  showAbout ||
  leaveConfirmOpen ||
  showTutorial;

const shouldLock = overlayOpen;

  document.documentElement.style.overflow = shouldLock ? 'hidden' : prevHtml || '';
  document.body.style.overflow = shouldLock ? 'hidden' : prevBody || '';

  return () => {
    document.documentElement.style.overflow = prevHtml;
    document.body.style.overflow = prevBody;
  };
}, [gameState, showAbout, victoryOpen, showTutorial, showDailyChooser, showFreePlayChooser, giveUpOpen, leaveConfirmOpen, isTouch, roundResolved, focusPostcodeInput]);

  // controls height -> CSS var
  useEffect(() => {
    if (!controlsRef.current) return;
    const setVar = () =>
      document.documentElement.style.setProperty('--controls-h', `${controlsRef.current.offsetHeight}px`);
    const ro = new ResizeObserver(setVar);
    ro.observe(controlsRef.current);
    setVar();
    return () => ro.disconnect();
  }, []);

  useEffect(() => {
    const ok = CSS.supports('backdrop-filter: blur(1px)') || CSS.supports('-webkit-backdrop-filter: blur(1px)');
    document.documentElement.classList.toggle('no-backdrop', !ok);
  }, []);

  useEffect(() => {
    console.log('Loaded postcode areas:', Object.keys(postcodeAreas).length);
    console.log('Sample path:', postcodeAreas['AB']?.path?.slice(0, 100));
  }, []);



  // ---------- Pan/zoom ----------
  const [scaleForLabels, setScaleForLabels] = useState(1);

  useEffect(() => {
    if (!svgRef.current || !contentRef.current || didAutoFitRef.current) return;
    const id = requestAnimationFrame(() => {
      try {
        const bbox = contentRef.current.getBBox();
        if (!bbox || bbox.width === 0 || bbox.height === 0) return;
        const PAD = 0.05;
        const availW = WORLD.width * (1 - PAD * 2);
        const availH = WORLD.height * (1 - PAD * 2);
        const s = Math.min(availW / bbox.width, availH / bbox.height);
        const tx0 = (WORLD.width  - s * bbox.width)  / 2 - s * bbox.x;
        const ty0 = (WORLD.height - s * bbox.height) / 2 - s * bbox.y;
        reset({ scale: s, x: tx0, y: ty0 });
        didAutoFitRef.current = true;
      } catch {}
    });
    return () => cancelAnimationFrame(id);
  }, [reset]);

  // ---------- Game logic ----------

const boundsByDifficulty = {
  easy:   { min: 3, max: 10 },
  normal: { min: 4, max: 12 },
  hard:   { min: 5, max: null },  // no max
  master: { min: 8, max: null },  // no max
  beta:   { min: 4, max: 12 },
};
  
function generatePuzzleWithBounds(minSteps, maxSteps = null, maxRetries = 800) {
  const areas = Object.keys(postcodeAreas);

  for (let attempt = 0; attempt < maxRetries; attempt++) {
    const start = areas[Math.floor(Math.random() * areas.length)];
    const dist = bfsAllDistances(start);

    // Candidates with distance in [minSteps, maxSteps] (or no max)
    const candidates = areas.filter(a => {
      if (a === start) return false;
      const d = dist.get(a);
      return Number.isFinite(d) && d >= minSteps && (maxSteps == null || d <= maxSteps);
    });

    if (candidates.length) {
      const target = candidates[Math.floor(Math.random() * candidates.length)];

      // double-check using your pathfinder
      const path = findShortestPath(start, target); // array of nodes
      const steps = path.length ? path.length - 1 : Infinity;
      if (Number.isFinite(steps) && steps >= minSteps && (maxSteps == null || steps <= maxSteps)) {
        return { start, target, path }; // path handy for optimalPath
      }
    }
  }

  // Fallback: keep the minimum strict, drop the max (so we always meet the min)
  console.warn('No pair within bounds after retries; relaxing max only.');
  return generatePuzzleWithBounds(minSteps, null, 200);
}

  const findShortestPath = (start, end) => {
    if (start === end) return [start];
    const queue = [[start]];
    const visited = new Set([start]);

    while (queue.length > 0) {
      const path = queue.shift();
      const current = path[path.length - 1];

      for (const neighbor of getNeighbors(current)) {
        if (neighbor === end) return [...path, neighbor];
        if (!visited.has(neighbor)) {
          visited.add(neighbor);
          queue.push([...path, neighbor]);
        }
      }
    }
    return [];
  };

const prevStateRef = useRef(gameState);

useEffect(() => {
  const attemptSummary = abandonActiveAttempt('stale_session', { onlyIfStale: true });
  syncAttemptSummary(attemptSummary);
}, []);

useEffect(() => {
  const prev = prevStateRef.current;
  if (prev !== 'playing' && gameState === 'playing') {
    roundIdRef.current = (crypto?.randomUUID?.() || `${Date.now()}-${Math.random()}`);
startAttempt({
  roundId: roundIdRef.current,
  difficulty,
  mode: dailyMode ? 'daily' : 'free',
  dailyDate,
  startArea,
  targetArea,
  inputStyle: analyticsInputStyle,
  mapStyle,
});
window.gtag?.('event', 'game_started', {
  round_id: roundIdRef.current,
  difficulty,
  mode: dailyMode ? 'daily' : 'free',
  daily_mode: dailyMode ? 1 : 0,
  start_postcode: startArea,
  target_postcode: targetArea,
  });
  }
  prevStateRef.current = gameState;
}, [gameState, difficulty, startArea, targetArea, dailyMode, dailyDate, analyticsInputStyle, mapStyle]);


const abandonIfActive = useCallback((reason = 'navigation') => {
  if (gameState === 'playing' && !gameWon) {
    const ms = gameStartRef.current ? Math.max(0, performance.now() - gameStartRef.current) : undefined;
    const attemptSummary = abandonActiveAttempt(reason, {
      moves: Math.max(0, currentPath.length - 1),
      durationMs: ms,
      hintsUsed,
      par: dailyMode ? dailyPar : Math.max(0, (optimalPath?.length || 1) - 1),
      optimalMoves: Math.max(0, (optimalPath?.length || 1) - 1),
      pathUsed: currentPath.slice(),
      inputStyle: analyticsInputStyle,
      mapStyle,
    });
    syncAttemptSummary(attemptSummary);
    if (window.gtag) {
window.gtag?.('event', 'game_abandoned', {
  round_id: roundIdRef.current,
  difficulty,
  mode: dailyMode ? 'daily' : 'free',
  daily_mode: dailyMode ? 1 : 0,
  start_postcode: startArea,
  target_postcode: targetArea,
  moves: Math.max(0, currentPath.length - 1),
  time_ms: ms,
  hints_used: hintsUsed,
  reason,
});
    }
    roundIdRef.current = null; // prevent duplicates
  }
}, [
  gameState, gameWon, difficulty, startArea, targetArea, currentPath,
  dailyMode, dailyPar, hintsUsed, optimalPath, analyticsInputStyle, mapStyle
]);

useEffect(() => {
  const onUnload = () => abandonIfActive('beforeunload');
  window.addEventListener('beforeunload', onUnload);
  return () => window.removeEventListener('beforeunload', onUnload);
}, [abandonIfActive]);




const backToMenu = React.useCallback(() => {
  // Daily autosaves — safe to leave immediately
  if (dailyMode) {
    abandonIfActive('menu');
    clearAchievementToasts();
    setGameState('menu');
    setBurgerOpen(false);
    return;
  }

  // Free Play: warn if an active, unfinished round
  if (gameState === 'playing' && !gameWon) {
    setLeaveConfirmOpen(true);
  } else {
    abandonIfActive('menu');
    clearAchievementToasts();
    setGameState('menu');
    setBurgerOpen(false);
  }
}, [dailyMode, gameState, gameWon, abandonIfActive, clearAchievementToasts]);

useEffect(() => {
  const onKey = (e) => {
    if (e.key !== 'Escape') return;
    e.preventDefault();

    // Close any open overlays first (topmost-first order)
    if (leaveConfirmOpen) { setLeaveConfirmOpen(false); return; }
    if (giveUpOpen)       { setGiveUpOpen(false);       return; }
    if (victoryOpen)      { setVictoryOpen(false);      return; }
    if (showDailyChooser) { setShowDailyChooser(false); return; }
    if (showFreePlayChooser) { setShowFreePlayChooser(false); return; }
    if (showAbout)        { setShowAbout(false);        return; }
    if (showTutorial)     { setShowTutorial(false);     return; }
    if (burgerOpen)       { setBurgerOpen(false);       return; }

    // No overlays open -> behave like Back button
    backToMenu();
  };

  window.addEventListener('keydown', onKey);
  return () => window.removeEventListener('keydown', onKey);
}, [
  backToMenu,
  leaveConfirmOpen, giveUpOpen, victoryOpen,
  showDailyChooser, showFreePlayChooser,
  showAbout, showTutorial, burgerOpen
]);


const startNewGame = () => {
  nudgeDismissedRef.current = false;
  setShowHints(false);
  clearAchievementToasts();
  abandonIfActive('reroll');

  const { min, max } = boundsByDifficulty[difficulty] ?? { min: 4, max: null };
  const { start, target, path } = generatePuzzleWithBounds(min, max);

  setStartArea(start);
  setTargetArea(target);
  setCurrentPath([start]);
  setGuesses([]);
  setGameWon(false);
  setDailyGaveUp(false);
  addVisited([start]);

  setOptimalPath(path);              // we already have it
  setGameState('playing');
  roundIdRef.current = (crypto?.randomUUID?.() || `${Date.now()}-${Math.random()}`);
  startAttempt({
    roundId: roundIdRef.current,
    difficulty,
    mode: dailyMode ? 'daily' : 'free',
    dailyDate,
    startArea: start,
    targetArea: target,
    inputStyle: analyticsInputStyle,
    mapStyle,
  });
  gameStartRef.current = null;
  setElapsedMs(0);
  setVictoryOpen(false);
  setShowOptimal(false);
  requestAnimationFrame(() => playDailyIntroTour(start, target));
  
};

// const minStepsByMode = { easy: 3, normal: 4, hard: 5, master: 6 };
const makeGuess = useCallback((area) => {
  if (gameWon || dailyGaveUp) return;
  if (gameState === 'playing' && !gameStartRef.current) {
    introTourRef.current += 1;
    gameStartRef.current = performance.now();
    setElapsedMs(0);
  }

  setErrorToast(prev => (prev ? '' : prev));
  clearAchievementToasts();
  setShowHints(false);

  const currentLocation = currentPath[currentPath.length - 1];
  const isKnownArea = !!postcodeAreas[area];
  const isValidMove = getNeighbors(currentLocation).includes(area);
  const alreadyVisited = currentPath.includes(area);
  const revisitAllowed = (difficulty === 'easy' || difficulty === 'normal');

  const viaFerry  = ferryAdj.get(currentLocation)?.has(area) || false;
  const viaBridge = !!bridgeAdj.get(currentLocation)?.has(area);

  setGuesses(prev => [...prev, { area, valid: isValidMove, alreadyVisited, viaFerry, viaBridge }]);

  if (!isValidMove || (alreadyVisited && !revisitAllowed)) {
    recordAttemptEvent('guess_incorrect', {
      from: currentLocation,
      guess: area,
      knownArea: isKnownArea,
      reason: !isKnownArea ? 'unknown_area' : alreadyVisited && !revisitAllowed ? 'revisit_blocked' : 'not_adjacent',
      moveNumber: Math.max(0, currentPath.length - 1),
    });
    setFlashAreas(prev => [...prev, area]);
    setTimeout(() => setFlashAreas(prev => prev.filter(a => a !== area)), 500);

    if (!isValidMove)        showError(`${area} isn’t adjacent to ${currentLocation}`);
    else if (alreadyVisited) showError(`You've already visited ${area} in this game. Revisiting is not allowed in ${difficulty} difficulty`);
    return;
  }

  // ✅ NEW: log lifetime stats for this valid move
  const moveType = viaFerry ? 'ferry' : viaBridge ? 'bridge' : 'land';
  recordLifetimeMove({ nextCode: area, type: moveType }, { onPersist });

  // existing meta-edge tracking / achievements
  if (viaFerry) {
    if (addUsedFerryEdge(currentLocation, area)) {
      const newly = checkAndUnlockMetaAchievements(difficulty, postcodeAreas, ferryLinks, bridgeLinks);
      if (newly.length) enqueueAchievementBatch(newly);
    }
  }
  if (viaBridge) {
    if (addUsedBridgeEdge(currentLocation, area)) {
      const newly = checkAndUnlockMetaAchievements(difficulty, postcodeAreas, ferryLinks, bridgeLinks);
      if (newly.length) enqueueAchievementBatch(newly);
    }
  }

  // mark newly visited (game-local)
  if (addVisited([area])) {
    const newly = checkAndUnlockMetaAchievements(difficulty, postcodeAreas, ferryLinks, bridgeLinks);
    if (newly.length) enqueueAchievementBatch(newly);
  }

  const newPath = [...currentPath, area];
setCurrentPath(newPath);

recordAttemptEvent('guess_correct', {
  from: currentLocation,
  to: area,
  moveType,
  moveNumber: Math.max(1, newPath.length - 1),
  path: newPath,
});



if (area === targetArea) {
  finishGame(newPath);
}
}, [
  getNeighbors, gameWon, currentPath, targetArea, finishGame,
  ferryAdj, bridgeAdj, difficulty, showError,
  onPersist, dailyGaveUp, gameState, enqueueAchievementBatch,clearAchievementToasts
]);

// const isFerryEdge  = (a,b) => ferryAdj.get(a)?.has(b)  || false;
// const isBridgeEdge = (a,b) => bridgeAdj.get(a)?.has(b) || false;



const handleClick = useCallback((code) => {
  if (!canClickAreas) return;
  if (gameState !== 'playing' || victoryOpen || showTutorial || showAbout) return;
  if (!isRevealed(code)) return;
  if (Date.now() < suppressClickUntilRef.current) return;
  makeGuess(code);
  
}, [gameState, isRevealed, makeGuess, canClickAreas, victoryOpen, showTutorial, showAbout]);


  // ---------- Label sizing helpers ----------
  const clamp = (v, lo, hi) => Math.max(lo, Math.min(hi, v));
  const labelPxForScale = (s) => clamp(30 + 200 * s, 30, 300); // readable range
  const svgFontSizeForScale = (s) => labelPxForScale(s) / s;

const resetView = useCallback(() => {
  hasFitRef.current = false;
  didAutoFitRef.current = false;

  requestAnimationFrame(() => {
    if (startArea && targetArea) {
      // pad controls how tight the frame is around the pair (0.2 ≈ your default)
      focusStartAndTarget(startArea, targetArea, 0.2);
    } else {
      // fallback if there’s no puzzle yet
      fitToContent();
    }
  });
}, [startArea, targetArea, focusStartAndTarget, fitToContent]);

React.useEffect(() => {
  // Only auto-focus for daily games
  if (!dailyMode) return;
  if (!startArea || !targetArea) return;

  // Use the same logic as the "Reset view" button
  resetView();
}, [dailyMode, startArea, targetArea, resetView]);



  // ---------- Optimal path overlay ----------

// ------------------- RENDER HELPERS (map, controls, menus) -----------------

  // ---------- Map ----------
const renderMap = () => (
  <GameMap
    WORLD={WORLD}
    arcPath={arcPath}
    arcPathBridge={arcPathBridge}
    arcPathFerry={arcPathFerry}
    attachPathRef={attachPathRef}
    canClickAreas={canClickAreas}
    centroidsRef={centroidsRef}
    contentRef={contentRef}
    currentArea={currentArea}
    currentPath={currentPath}
    difficulty={difficulty}
    ferryLinks={ferryLinks}
    flashAreas={flashAreas}
    gameWon={gameWon}
    roundResolved={roundResolved}
    getAreaStyle={getAreaStyle}
    getCenter={getCenter}
    gRef={gRef}
    handleClick={handleClick}
    isRevealed={isRevealed}
    labelVisibleAtScale={labelVisibleAtScale}
    landClipId={landClipId}
    linkPaint={linkPaint}
    masterMode={masterMode}
    optimalPath={optimalPath}
    scaleForLabels={scaleForLabels}
    showLabels={showLabels}
    showOptimal={showOptimal}
    showOutlines={showOutlines}
    startArea={startArea}
    svgFontSizeForScale={svgFontSizeForScale}
    svgRef={svgRef}
    targetArea={targetArea}
    mapStyle={mapStyle}
  />
);


  

  // ---------- Controls / UI ----------

useEffect(() => {
  setJourneyExpanded(false);
}, [startArea, targetArea, dailyDate, gameState]);

useEffect(() => {
  const el = journeyRailRef.current;
  if (!el) return;
  try {
    el.scrollTo({ left: el.scrollWidth, behavior: 'smooth' });
  } catch {
    el.scrollLeft = el.scrollWidth;
  }
}, [currentPath, journeyExpanded]);

const getVisibleJourneyItems = useCallback(() => {
  const path = currentPath || [];
  const len = path.length;

  if (journeyExpanded || len <= 6) {
    return path.map((code, i) => ({ type: 'step', code, index: i }));
  }

  const items = [];
  items.push({ type: 'step', code: path[0], index: 0 });
  items.push({ type: 'ellipsis' });

  const tailStart = Math.max(1, len - 5);
  for (let i = tailStart; i < len; i++) {
    items.push({ type: 'step', code: path[i], index: i });
  }

  return items;
}, [currentPath, journeyExpanded]);

const renderControls = () => (
  <div ref={controlsRef} className="pp-controls-layer top-0 z-20 w-full">
<div
  ref={topOverlayRef}
  className="pp-top-overlay glass glass--white mx-auto relative"
      style={{ width: '100%', maxWidth: '600px', overflowX: 'auto', overflowY: 'visible', WebkitOverflowScrolling: 'touch' }}
    >
      <div className="grid-container">
        <div>
          <button
            type="button"
            className="btn btn-primary px-3 py-1 text-sm"
            onClick={backToMenu}
            aria-label="Back to menu"
            title="Back to menu (Esc)"
          >
            <ArrowBigLeft w-4 h-4 />
          </button>
        </div>

<div className="text-center leading-tight text-[clamp(11px,2.6vw,13px)]">
  <div className="flex flex-col items-center gap-1">
    <div className="whitespace-nowrap">Travel from</div>

    <div className="flex items-center justify-center gap-2 flex-wrap">
      <button
        type="button"
        className="btn btn-start"
        onClick={() => startArea && centerOn(startArea)}
        disabled={!startArea}
        aria-label={startArea ? `Center map on start postcode ${startArea}` : 'No start postcode'}
        title={startArea ? `Center on start: ${startArea}` : ''}
      >
        
        {startArea || '—'}
      </button>

      <span className="text-slate-700 font-semibold" aria-hidden="true"> to </span>

      <button
        type="button"
        className="btn btn-target"
        onClick={() => targetArea && centerOn(targetArea)}
        disabled={!targetArea}
        aria-label={targetArea ? `Center map on target postcode ${targetArea}` : 'No target postcode'}
        title={targetArea ? `Center on target: ${targetArea}` : ''}
      >
        
        {targetArea || '—'}
      </button>
    </div>

    {dailyMode && Number.isFinite(dailyPar) && (
      <span className="badge badge-gray inline-flex items-center !text-[11px] !leading-tight !py-0.5 !px-2 align-middle">
        <span className="mr-1 align-[-0.1em]">⛳</span>
        Par {dailyPar}
      </span>
    )}
  </div>
</div>


        <div>
          <button
            ref={burgerButtonRef}
            type="button"
            className="btn btn-primary inline-flex w-auto items-center gap-2"
            aria-haspopup="menu"
            aria-expanded={burgerOpen ? 'true' : 'false'}
            aria-label="Open menu"
            onClick={() => setBurgerOpen(o => !o)}
          >
            <Menu className="w-4 h-4" />
          </button>
        </div>
      </div>

      {burgerOpen && createPortal(
        <div
          className={`pp-game-menu-layer ${isTouch ? 'is-sheet' : 'is-dropdown'}`}
          onClick={() => setBurgerOpen(false)}
        >
          <div
            id="pp-burger-menu"
            role="menu"
            aria-orientation="vertical"
            className={`pp-game-menu ${isTouch ? 'pp-game-menu-sheet' : 'pp-game-menu-dropdown'} ${menuAnimClass}`}
            style={isTouch ? undefined : { top: burgerPos.top, right: Math.max(12, window.innerWidth - burgerPos.left - burgerPos.width) }}
            onClick={(e) => e.stopPropagation()}
          >
            <div className="pp-game-menu-head">
              <div className="pp-game-menu-eyebrow">{dailyMode ? 'Daily Challenge' : 'Game menu'}</div>
              <div className="pp-game-menu-title">
                {dailyMode
                  ? `${DIFF_LABELS[dailyDifficulty] || dailyDifficulty || 'Daily'} ${roundResolved ? '· Complete' : '· In progress'}`
                  : `${DIFF_LABELS[difficulty] || difficulty || 'Free Play'} Free Play`}
              </div>
              {dailyMode && !roundResolved && (
                <div className="pp-game-menu-pill">{Math.max(0, MAX_DAILY_HINTS - hintsUsed)} hints left</div>
              )}
            </div>

            <div className="pp-game-menu-section">
              <div className="pp-game-menu-label">{dailyMode ? 'Daily controls' : 'Game'}</div>
              <button
                type="button"
                role="menuitem"
                className="pp-game-menu-item"
                onClick={() => { localStorage.removeItem(ONBOARDING_KEY); setShowTutorial(true); setBurgerOpen(false); }}
              >
                <BookOpen className="w-4 h-4" aria-hidden="true" />
                <span>How to Play</span>
              </button>

              <button
                type="button"
                role="menuitem"
                className={`pp-game-menu-item ${dailyMode ? 'is-disabled' : 'is-emphasis'}`}
                onClick={dailyMode ? undefined : () => { fireReroll?.('new_game_button'); startNewGame(); setBurgerOpen(false); }}
                disabled={dailyMode}
                aria-disabled={dailyMode}
                title={dailyMode ? 'Unavailable during Daily Challenge' : 'Start a new random game'}
              >
                <Flag className="w-4 h-4" aria-hidden="true" />
                <span>
                  New Game
                  {dailyMode && <small>Unavailable during Daily</small>}
                </span>
              </button>

              <button
                type="button"
                role="menuitem"
                className={`pp-game-menu-item ${dailyMode ? 'is-disabled' : 'is-warn'}`}
                onClick={dailyMode ? undefined : () => {
                  abandonIfActive('restart');
                  setCurrentPath([startArea]);
                  setGuesses([]);
                  clearAchievementToasts();
                  setGameWon(false);
                  const restartedOptimal = findShortestPath(startArea, targetArea);
                  setOptimalPath(restartedOptimal);
                  roundIdRef.current = (crypto?.randomUUID?.() || `${Date.now()}-${Math.random()}`);
                  startAttempt({
                    roundId: roundIdRef.current,
                    difficulty,
                    mode: dailyMode ? 'daily' : 'free',
                    dailyDate,
                    startArea,
                    targetArea,
                    inputStyle: analyticsInputStyle,
                    mapStyle,
                  });
                  setBurgerOpen(false);
                }}
                disabled={dailyMode}
                aria-disabled={dailyMode}
                title={dailyMode ? 'Unavailable during Daily Challenge' : 'Restart this round'}
              >
                <Route className="w-4 h-4" aria-hidden="true" />
                <span>
                  Restart
                  {dailyMode && <small>Unavailable during Daily</small>}
                </span>
              </button>
            </div>

            <div className="pp-game-menu-section">
              <div className="pp-game-menu-label">Account</div>
              <div className="pp-game-menu-account">
                <AuthButton variant="label" />
              </div>
            </div>

            <div className="pp-game-menu-section">
              <button
                type="button"
                role="menuitem"
                className="pp-game-menu-item"
                onClick={() => { navigate('settings'); setBurgerOpen(false); }}
              >
                <Settings2 className="w-4 h-4" aria-hidden="true" />
                <span>Settings</span>
              </button>

              <button
                type="button"
                role="menuitem"
                className="pp-game-menu-item"
                onClick={() => { navigate('privacy'); setBurgerOpen(false); }}
              >
                <Eye className="w-4 h-4" aria-hidden="true" />
                <span>Privacy</span>
              </button>
            </div>
          </div>
        </div>,
        document.body
      )}
    </div>

    <div className="pp-controls-spacer" aria-hidden="true" />

    <div
      ref={bottomOverlayRef}
      className="pp-bottom-overlay mx-auto"
      style={{ width: '100%', maxWidth: '630px', overflowX: 'auto', overflowY: 'auto', maxHeight: '1000px', WebkitOverflowScrolling: 'touch', paddingBottom: 'env(safe-area-inset-bottom, 12px)' }}
    >
      {!roundResolved && (
        <div className="px-3 pb-3 pt-2">
          {useMobileInput ? (
            <div className="glass glass--white rounded-xl overflow-hidden">
              <div className="pp-mobile-tabs" role="tablist" aria-label="Mobile controls">
                {['enter', 'journey', 'actions'].map(tab => (
                  <button
                    key={tab}
                    type="button"
                    role="tab"
                    aria-selected={mobileControlsTab === tab}
                    className={`pp-mobile-tab ${mobileControlsTab === tab ? 'active' : ''}`}
                    onClick={() => setMobileControlsTab(tab)}
                  >
                    {tab === 'enter' ? 'Enter' : tab === 'journey' ? 'Journey' : 'Actions'}
                  </button>
                ))}
              </div>

              {mobileControlsTab === 'enter' && (
                <MobileCodeScroller
                  current={currentPath[currentPath.length - 1]}
                  onPick={(code) => {
                    const currentLocation = currentPath[currentPath.length - 1];
                    const isKnownArea = !!postcodeAreas[code];
                    const isValidMove = getNeighbors(currentLocation).includes(code);
                    const alreadyVisited = currentPath.includes(code);
                    const revisitAllowed = difficulty === 'easy' || difficulty === 'normal';
                    const allowedMove = isValidMove && (!alreadyVisited || revisitAllowed);

                    makeGuess(code);

                    if (!isKnownArea) return;

                    requestAnimationFrame(() => {
                      zoomToArea(code, { duration: allowedMove ? 0 : 250 });

                      if (!allowedMove) {
                        window.setTimeout(() => {
                          zoomToArea(currentLocation, { duration: 450 });
                        }, 700);
                      }
                    });
                  }}
                  getNeighbors={getNeighbors}
                  currentPath={currentPath}
                  allCodes={allPostcodeOptions}
                />
              )}

              {mobileControlsTab === 'journey' && (
                <div className="p-3">
                  <div ref={journeyRailRef} className="journey-rail flex items-center gap-2 overflow-x-auto whitespace-nowrap">
                    {getVisibleJourneyItems().map((item, railIdx) => {
                      if (item.type === 'ellipsis') {
                        return (
                          <button key={`mobile-ellipsis-${railIdx}`} type="button" onClick={() => setJourneyExpanded(true)} className="badge badge-gray shrink-0" aria-label="Show full journey">...</button>
                        );
                      }

                      const { code, index: i } = item;
                      const type = i > 0 ? edgeType(currentPath[i - 1], code) : null;
                      const base = i === currentPath.length - 1 ? 'badge-blue' : 'badge-green';
                      const title = i === 0 ? 'Start area' : i === currentPath.length - 1 ? 'Current area' : type === 'ferry' ? 'Reached by ferry' : type === 'bridge' ? 'Reached by bridge/tunnel' : 'Land border';

                      return (
                        <button key={`mobile-${code}-${i}`} type="button" onClick={() => centerOn(code)} className={`badge ${base} inline-flex items-center shrink-0`} title={title} aria-label={`Center map on ${code} (${title})`}>
                          <span style={{ marginRight: 6 }}>{i === 0 ? 'Start' : i === currentPath.length - 1 ? 'Current' : i}</span>
                          {code}
                          {type === 'ferry' && <Ship className="w-3 h-3 ml-1" aria-hidden="true" />}
                          {type === 'bridge' && <Route className="w-3 h-3 ml-1" aria-hidden="true" />}
                        </button>
                      );
                    })}
                    {journeyExpanded && currentPath.length > 6 && (
                      <button type="button" onClick={() => setJourneyExpanded(false)} className="badge badge-green shrink-0" aria-label="Collapse journey">Collapse</button>
                    )}
                  </div>
                  {guesses.length > 0 && (
                    <div className="flex flex-wrap gap-1 text-xs mt-3">
                      <span className="text-slate-600">Last entry:</span>
                      {guesses.slice(-1).map((g, i) => (
                        <span key={i} className={`px-2 py-1 rounded ${g.valid && !g.alreadyVisited ? 'bg-emerald-100 text-emerald-800' : g.alreadyVisited ? 'bg-amber-100 text-amber-800' : 'bg-rose-100 text-rose-800'}`}>
                          {g.area}{g.valid && !g.alreadyVisited && g.viaFerry ? ' (ferry)' : ''}{g.valid && !g.alreadyVisited && g.viaBridge ? ' (bridge)' : ''}
                        </span>
                      ))}
                    </div>
                  )}
                </div>
              )}

              {mobileControlsTab === 'actions' && (
                <div className="p-3 grid grid-cols-3 gap-2">
                  {!masterMode && (
                    <button onClick={undoLastMove} disabled={currentPath.length <= 1} aria-disabled={currentPath.length <= 1} className={`btn btn-neutral m-0 ${currentPath.length <= 1 ? 'opacity-50 cursor-not-allowed' : ''}`}>Undo</button>
                  )}
                  {masterMode && <span />}
                  <button className="btn btn-warn m-0" onClick={() => setGiveUpOpen(true)}>Give up</button>
                  <button className="btn btn-success m-0" onClick={toggleHints} disabled={dailyMode && hintsUsed >= MAX_DAILY_HINTS && !showHints}>
                    {dailyMode ? `Hints (${Math.max(0, MAX_DAILY_HINTS - hintsUsed)})` : 'Hints'}
                  </button>
                </div>
              )}
            </div>
          ) : (
            <div className="w-full">
              <div
                style={{ position: 'relative', textAlign: 'center', width: 'min(400px, calc(100vw - 24px))', maxWidth: '100%', margin: '0 auto' }}
                className={shouldPulse ? 'pp-pulse-wrap' : undefined}
              >
                <input
                  ref={inputRef}
                  list="pp-codelist"
                  type="text"
                  placeholder='Enter a Postcode'
                  className="rounded-2xl border border-slate-300 text-center shadow-md focus:ring-4 focus:ring-indigo-400 focus:outline-none"
                  onInput={handleSelectorInput}
                  onKeyDown={(e) => { if (e.key === 'Enter') handleInputSubmit(e.currentTarget); }}
                  autoCapitalize="characters"
                  autoCorrect="off"
                  spellCheck={false}
                  inputMode="text"
                  enterKeyHint="go"
                  aria-label="Select or enter a postcode"
                  style={{
                    width: '100%',
                    boxSizing: 'border-box',
                    height: 20,
                    fontSize: 'clamp(22px, 9vw, 28px)',
                    padding: '16px 56px 16px 18px',
                    
                    letterSpacing: '0.04em',
                    display: 'inline-block',
                    margin: '0 auto',
                    borderRadius: 45,
                  }}
                />
                <datalist id="pp-codelist">
                  {allPostcodeOptions.map(code => <option key={code} value={code} />)}
                </datalist>
                <button
                  type="button"
                  onClick={() => inputRef.current && handleInputSubmit(inputRef.current)}
                  className="btn btn-hollowgreen rounded-xl shadow"
                  aria-label="Submit postcode"
                  style={{
                    position: 'absolute',
                    top: '48%',
                    right: 8,
                    transform: 'translateY(-50%)',
                    width: 35,
                    height: 35,
                    padding: 0,
                    lineHeight: 1,
                    display: 'grid',
                    placeItems: 'center',
                    zIndex: 1,
                    borderRadius: 45,
                  }}
                >
                  <ArrowRight className="w-6 h-6" />
                </button>
              </div>
            </div>
          )}
        </div>
      )}

      {useMobileInput && roundResolved && (
        <div className="glass glass--white rounded-xl px-3 py-3">
          <div className="flex flex-wrap items-center gap-2">
            <div className="inline-flex min-w-0 flex-1 items-center gap-2 rounded border border-emerald-300 bg-emerald-100 px-2 py-1 text-emerald-900">
              <Trophy className="h-4 w-4 shrink-0" />
              <span className="min-w-0 text-sm">
                {gameWon ? <>Completed in <b>{Math.max(0, currentPath.length - 1)}</b></> : <>Gave up after <b>{Math.max(0, currentPath.length - 1)}</b></>}
                {optimalPath.length > 0 && <> · Optimal <b>{Math.max(0, optimalPath.length - 1)}</b></>}
              </span>
            </div>

            <button onClick={() => setShowOptimal(v => !v)} className="btn btn-purple shrink-0">
              {showOptimal ? 'Hide optimal route' : 'Show optimal route'}
            </button>
          </div>
        </div>
      )}

      {!useMobileInput && (
      <div className="glass glass--white px-3 pb-2">
        <div className="flex flex-wrap items-center gap-2">
          <div
            ref={journeyRailRef}
            className="journey-rail flex min-w-0 flex-1 items-center gap-2 overflow-x-auto whitespace-nowrap"
          >
            <span className="text-slate-200/90 shrink-0">Journey:</span>
            {getVisibleJourneyItems().map((item, railIdx) => {
              if (item.type === 'ellipsis') {
                return (
                  <button
                    key={`ellipsis-${railIdx}`}
                    type="button"
                    onClick={() => setJourneyExpanded(true)}
                    className="badge badge-gray shrink-0"
                    title="Show full journey"
                    aria-label="Show full journey"
                  >
                    ...
                  </button>
                );
              }

              const { code, index: i } = item;
              const type = i > 0 ? edgeType(currentPath[i - 1], code) : null;
              const base =
                code === targetArea ? 'badge-green' :
                i === currentPath.length - 1 ? 'badge-blue' :
                code === startArea ? 'badge-green' :
                type === 'ferry' ? 'badge-green' :
                type === 'bridge' ? 'badge-green' :
                'badge-green';
              const title =
                i === 0 ? 'Start area' :
                i === currentPath.length - 1 ? 'Current area' :
                type === 'ferry' ? 'Reached by ferry' :
                type === 'bridge' ? 'Reached by bridge/tunnel' :
                'Land border';

              return (
                <button
                  key={`${code}-${i}`}
                  type="button"
                  onClick={() => centerOn(code)}
                  className={`badge ${base} inline-flex items-center shrink-0 cursor-pointer focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:ring-offset-2`}
                  title={title}
                  aria-label={`Center map on ${code} (${title})`}
                >
                  <span style={{ marginRight: 6 }}>
                    {i === 0 ? 'Start' : i === currentPath.length - 1 ? 'Current' : i}
                  </span>
                  {code}
                  {type === 'ferry' && <Ship className="w-3 h-3 ml-1" aria-hidden="true" />}
                  {type === 'bridge' && <Route className="w-3 h-3 ml-1" aria-hidden="true" />}
                </button>
              );
            })}

            {journeyExpanded && currentPath.length > 6 && (
              <button
                type="button"
                onClick={() => setJourneyExpanded(false)}
                className="badge badge-green shrink-0"
                title="Collapse journey"
                aria-label="Collapse journey"
              >
                Collapse
              </button>
            )}
          </div>

          <div>
            {guesses.length > 0 && (
              <div className="flex flex-wrap gap-1 text-xs mt-3 justify-center">
                Last entry:&nbsp;
                {guesses.slice(-1).map((g, i) => (
                  <span
                    key={i}
                    className={`px-2 py-1 rounded ${
                      g.valid && !g.alreadyVisited
                        ? 'bg-emerald-100 text-emerald-800'
                        : g.alreadyVisited
                          ? 'bg-amber-100 text-amber-800'
                          : 'bg-rose-100 text-rose-800'
                    }`}
                  >
                    {g.area}
                    {g.valid && !g.alreadyVisited && g.viaFerry ? ' (ferry)' : ''}
                    {g.valid && !g.alreadyVisited && g.viaBridge ? ' (bridge)' : ''}
                  </span>
                ))}
              </div>
            )}
          </div>

          <div className="ml-auto flex shrink-0 items-center gap-2">
            {!roundResolved && !masterMode && (
              <button
                onClick={undoLastMove}
                disabled={currentPath.length <= 1}
                aria-disabled={currentPath.length <= 1}
                title="Undo last move (Ctrl/Cmd+Z)"
                className={`btn btn-neutral ${currentPath.length <= 1 ? 'opacity-50 cursor-not-allowed' : ''}`}
              >
                Undo
              </button>
            )}

            {!roundResolved && (
              <button className="btn btn-warn" onClick={() => setGiveUpOpen(true)} title="End this game as a loss">
                Give up
              </button>
            )}

            {giveUpOpen && createPortal(
              <div
                style={{
                  position: 'fixed',
                  inset: 0,
                  background: 'rgba(0,0,0,0.6)',
                  zIndex: 2147483647,
                  display: 'flex',
                  justifyContent: 'center',
                  alignItems: 'flex-start',
                  paddingTop: '10vh',
                  padding: '10vh 16px 16px',
                }}
                onClick={() => setGiveUpOpen(false)}
              >
                <div
                  className="glass p-5 rounded-2xl shadow-xl text-center"
                  style={{ maxWidth: 520, width: '92vw', maxHeight: '80vh', overflowY: 'auto' }}
                  onClick={(e) => e.stopPropagation()}
                  role="dialog"
                  aria-modal="true"
                  aria-labelledby="giveup-title"
                >
                  <h2 id="giveup-title" className="text-xl font-semibold mb-2">Give up?</h2>
                  <p className="mb-4">
                    This will record a <b>loss</b> for this {dailyMode ? 'Daily' : 'Free Play'} game{dailyMode ? ' and reveal the optimal path' : ''}.<br />
                    Current route: <b>{Math.max(0, currentPath.length - 1)}</b> moves
                    {optimalPath.length > 0 && <> · Optimal: <b>{Math.max(0, optimalPath.length - 1)}</b></>}
                  </p>
                  <div className="flex gap-2 justify-center">
                    <button onClick={giveUpNow} className="btn btn-warn glass">Give up</button>
                    <button onClick={() => setGiveUpOpen(false)} className="btn btn-neutral glass">Cancel</button>
                  </div>
                </div>
              </div>,
              document.body
            )}

            {!roundResolved && (
              <button
                className="btn btn-success"
                onClick={toggleHints}
                disabled={dailyMode && hintsUsed >= MAX_DAILY_HINTS && !showHints}
                title={dailyMode ? `Hints left: ${Math.max(0, MAX_DAILY_HINTS - hintsUsed)}` : 'Show possible neighbours'}
              >
                {dailyMode
                  ? `Hints (${Math.max(0, MAX_DAILY_HINTS - hintsUsed)} left)`
                  : 'Hints'}
              </button>
            )}

            {roundResolved && (
              <>
                <div className="inline-flex items-center gap-2 px-2 py-1 rounded border border-emerald-300 bg-emerald-100 text-emerald-900">
                  <Trophy className="w-4 h-4" />
                  <span>
                    {gameWon ? <>Completed in <b>{Math.max(0, currentPath.length - 1)}</b></> : <>Gave up after <b>{Math.max(0, currentPath.length - 1)}</b></>}
                    {optimalPath.length > 0 && <> · Optimal <b>{Math.max(0, optimalPath.length - 1)}</b></>}
                  </span>
                </div>

                <button onClick={() => setShowOptimal(v => !v)} className="btn btn-purple">
                  {showOptimal ? 'Hide optimal route' : 'Show optimal route'}
                </button>
              </>
            )}
          </div>
        </div>
      </div>

      )}

      {useMobileInput && giveUpOpen && createPortal(
        <div
          style={{
            position: 'fixed',
            inset: 0,
            background: 'rgba(0,0,0,0.6)',
            zIndex: 2147483647,
            display: 'flex',
            justifyContent: 'center',
            alignItems: 'flex-start',
            paddingTop: '10vh',
            padding: '10vh 16px 16px',
          }}
          onClick={() => setGiveUpOpen(false)}
        >
          <div
            className="glass p-5 rounded-2xl shadow-xl text-center"
            style={{ maxWidth: 520, width: '92vw', maxHeight: '80vh', overflowY: 'auto' }}
            onClick={(e) => e.stopPropagation()}
            role="dialog"
            aria-modal="true"
            aria-labelledby="giveup-title-mobile"
          >
            <h2 id="giveup-title-mobile" className="text-xl font-semibold mb-2">Give up?</h2>
            <p className="mb-4">
              This will record a <b>loss</b> for this {dailyMode ? 'Daily' : 'Free Play'} game{dailyMode ? ' and reveal the optimal path' : ''}.<br />
              Current route: <b>{Math.max(0, currentPath.length - 1)}</b> moves
              {optimalPath.length > 0 && <> - Optimal: <b>{Math.max(0, optimalPath.length - 1)}</b></>}
            </p>
            <div className="flex gap-2 justify-center">
              <button onClick={giveUpNow} className="btn btn-warn glass">Give up</button>
              <button onClick={() => setGiveUpOpen(false)} className="btn btn-neutral glass">Cancel</button>
            </div>
          </div>
        </div>,
        document.body
      )}
      <GameModal
        open={showHints && !roundResolved && currentPath.length > 0}
        onClose={() => setShowHints(false)}
        title={dailyMode ? `Available connections (${Math.max(0, MAX_DAILY_HINTS - hintsUsed)} left)` : 'Available connections'}
      >
        <p className={`mb-3 rounded-lg border px-3 py-2 text-sm ${
          dailyMode
            ? 'border-sky-200 bg-sky-50 text-sky-900'
            : 'border-amber-200 bg-amber-50 text-amber-900'
        }`}>
          {dailyMode
            ? 'Daily hints are limited. Streak and exploration achievements still count, but challenge achievements require a no-hint run.'
            : 'This run is now assisted. Exploration achievements still count, but challenge achievements require a no-hint run.'}
        </p>
        {(() => {
          const current = currentPath[currentPath.length - 1];
          const options = getNeighbors(current)
            .filter(n => !currentPath.includes(n))
            .map(n => ({ n, d: bfsDistance(n, targetArea) }))
            .sort((a, b) => a.d - b.d);

          if (options.length === 0) {
            return <span className="badge badge-fail">No unvisited neighbours</span>;
          }

          return (
            <div className="badges flex flex-wrap items-center gap-2">
              {options.map(({ n, d }, idx) => {
                const best = idx === 0;
                const className = best ? 'badge badge-blue hover:brightness-95' : 'badge badge-gray hover:brightness-95';
                return (
                  <button
                    key={n}
                    type="button"
                    className={className}
                    onClick={() => {
                      makeGuess(n);
                      setShowHints(false);
                    }}
                    title={Number.isFinite(d) ? `~${d} steps from target` : 'No path'}
                    aria-label={Number.isFinite(d) ? `${n}, about ${d} steps from target` : `${n}, no path`}
                  >
                    {n}
                  </button>
                );
              })}
            </div>
          );
        })()}
      </GameModal>

      {(roundResolved && showOptimal && optimalPath?.length > 0) && (
        <div className="mt-3">
          <div className="text-sm font-semibold mb-1">Optimal route:</div>
          <div className="badges flex flex-wrap items-center gap-2">
            {optimalPath.map((code, i) => (
              <span key={i} className="badge badge-best">
                <span style={{ marginRight: 6 }}>{i}:</span>
                {code}
              </span>
            ))}
          </div>
        </div>
      )}

      <ToastShell
        open={showNudge && !masterMode && !roundResolved}
        onClose={dismissNudge}
        width={360}
      >
        <TipToast
          title="Tip"
          eyebrow="For newer players"
          onClose={dismissNudge}
          action={{
            label: 'Open tutorial',
            onClick: () => {
              setShowTutorial(true);
              dismissNudge();
            }
          }}
        >
          You are in the <b>glowing postcode area</b>. Enter and select a neighbouring postcode area like <b>{exampleNeighbor}</b>. If you're still unsure, try the tutorial.
        </TipToast>
      </ToastShell>

      <ToastShell
        open={!!errorToast}
        onClose={() => {
          setErrorToast('');
          focusPostcodeInput();
        }}
        width={420}
      >
        <ErrorToast
          message={errorToast}
          onClose={() => {
            setErrorToast('');
            focusPostcodeInput();
          }}
        />
      </ToastShell>

      {achievementToasts[0] && (
        <ToastShell
          open
          onClose={() => {
            setAchievementToasts(q => q.slice(1));
            focusPostcodeInput();
          }}
          width={420}
        >
          {achievementToasts[0].kind === 'group' ? (
            <div
              style={{
                borderRadius: 22,
                overflow: 'hidden',
                boxShadow: '0 28px 60px rgba(0,0,0,0.35)',
                border: '1px solid rgba(255,255,255,0.16)',
                background: 'rgba(9,14,28,0.78)',
                backdropFilter: 'blur(16px)',
                WebkitBackdropFilter: 'blur(16px)',
                color: 'white',
              }}
            >
              <div style={{ height: 4, background: 'linear-gradient(90deg, #22c55e, #06b6d4, #8b5cf6)' }} />
              <div style={{ padding: 18, display: 'flex', gap: 14, alignItems: 'flex-start' }}>
                <div
                  style={{
                    width: 42,
                    height: 42,
                    borderRadius: 14,
                    background: 'rgba(34,197,94,0.18)',
                    display: 'grid',
                    placeItems: 'center',
                    flexShrink: 0,
                  }}
                >
                  <Trophy size={22} />
                </div>

                <div style={{ flex: 1 }}>
                  <div style={{ fontWeight: 800, fontSize: 16 }}>Achievements unlocked</div>
                  <div style={{ color: 'rgba(255,255,255,0.82)', fontSize: 14, marginTop: 4 }}>
                    <strong>{achievementToasts[0].items.length} achievements earned</strong>
                  </div>

                  <div style={{ marginTop: 12, display: 'grid', gap: 10 }}>
                    {achievementToasts[0].items.map((item) => (
                      <div
                        key={item.id || item.name}
                        style={{
                          borderRadius: 14,
                          padding: '10px 12px',
                          background: 'rgba(255,255,255,0.08)',
                          border: '1px solid rgba(255,255,255,0.10)',
                        }}
                      >
                        <div style={{ fontWeight: 700, fontSize: 15 }}>{item.name}</div>
                        {item.description ? (
                          <div style={{ color: 'rgba(255,255,255,0.82)', fontSize: 14, marginTop: 2 }}>
                            {item.description}
                          </div>
                        ) : null}
                      </div>
                    ))}
                  </div>

                  <div style={{ display: 'flex', gap: 10, marginTop: 14, flexWrap: 'wrap' }}>
                    <button
                      className="btn btn-success"
                      onClick={() => {
                        setAchievementToasts(q => q.slice(1));
                        focusPostcodeInput();
                      }}
                    >
                      Nice
                    </button>
                    <button
                      className="btn btn-neutral"
                      onClick={() => {
                        setAchievementToasts(q => q.slice(1));
                        focusPostcodeInput();
                      }}
                    >
                      Dismiss
                    </button>
                  </div>
                </div>
              </div>
            </div>
          ) : (
            <AchievementToast
              icon={achievementToasts[0].icon}
              title={achievementToasts[0].name}
              description={achievementToasts[0].description}
              onClose={() => {
                setAchievementToasts(q => q.slice(1));
                focusPostcodeInput();
              }}
            />
          )}
        </ToastShell>
      )}
      
    </div>
  </div>
);

useEffect(() => {
  const overlayOpen =
    showDailyChooser || showFreePlayChooser ||
    victoryOpen || giveUpOpen || showAbout || showHints ||
    leaveConfirmOpen || showTutorial;

  if (!overlayOpen && !useMobileInput && gameState === 'playing' && !roundResolved) {
    focusPostcodeInput();
  }

  const shouldLock = overlayOpen

  if (shouldLock) {
    const y = window.scrollY;
    document.body.dataset.ppScrollY = String(y);
    document.body.style.position = 'fixed';
    document.body.style.top = `-${y}px`;
    document.body.style.left = '0';
    document.body.style.right = '0';
    document.body.style.width = '100%';
    document.body.style.overflow = 'hidden';
    // ✗ do not touch documentElement
  } else {
    const y = parseInt(document.body.dataset.ppScrollY || '0', 10);
    document.body.style.position = '';
    document.body.style.top = '';
    document.body.style.left = '';
    document.body.style.right = '';
    document.body.style.width = '';
    document.body.style.overflow = '';
    delete document.body.dataset.ppScrollY;
    window.scrollTo(0, y);
  }
}, [
  gameState,
  showDailyChooser, showFreePlayChooser,
  victoryOpen, giveUpOpen, showAbout, showHints, leaveConfirmOpen, showTutorial,
  focusPostcodeInput, useMobileInput, roundResolved
]);




// ---------- GameBoard ----------

const renderGameBoard = () => (
  <GameBoard map={renderMap()} controls={renderControls()} />
);

// ---------- Menu page ----------

function handleDailyChoice(diff) {
  const status = normalizeStatus(Daily.dailyStatus?.(diff)); // 'idle' | 'continue' | 'finished' | 'gaveUp'
  if (status === 'finished' || status === 'continue' || status === 'gaveUp') {
    // jump straight in: resume or show the result
    startOrResumeDaily(diff);
    setShowDailyChooser(false);
    setDailyChoice(null);
    return;
  }
  // otherwise, show the info panel with Play button
  setDailyChoice(diff);
}

const renderMenu = () => (
  <div className="max-w-2xl mx-auto p-8 glass glass--slate text-center mt-8 relative">
    
    
<img src="logo192.png" alt="Postcode Pursuit logo" height="100" className="w-32 h-auto mx-auto mb-4" />
    <h1 className="text-3xl font-bold text-slate-900 mb-2 tracking-tight">Postcode Pursuit</h1>
        <div className="absolute top-2 right-2 flex items-center gap-2">
<AuthButton size="btn-sm" />
      </div>


    <div className="mt-6 px-2">
      <div className="pp-menu-primary-wrap">
        <button
          type="button"
          className="lrgbtn btn-glass tint-green btn-cta min-h-[5.25rem] text-xl sm:text-2xl"
          style={{ width: '100%', height: '5.25rem', margin: 0 }}
          onClick={() => setShowDailyChooser(true)}
        >
          <Trophy className="w-7 h-7 shrink-0" aria-hidden="true" />
          <span>Daily Challenge</span>
        </button>
      </div>
    </div>

    <div className="mt-3 px-2">
      <div className="pp-menu-secondary-tray">
        <div className="pp-menu-secondary-row">
          <button
            type="button"
            className="lrgbtn btn-glass tint-blue btn-cta min-h-[3.25rem] text-base"
            style={{ width: '100%', margin: 0 }}
            onClick={() => setShowFreePlayChooser(true)}
          >
            <Flag className="w-5 h-5 shrink-0" aria-hidden="true" />
            <span>Free Play</span>
          </button>

          <button
            type="button"
            className="lrgbtn btn-glass glass--white btn-cta min-h-[3.25rem] text-base"
            style={{ width: '100%', margin: 0 }}
            onClick={() => setShowTutorial(true)}
          >
            <BookOpen className="w-5 h-5 shrink-0" aria-hidden="true" />
            <span>How to Play</span>
          </button>
        </div>

        <div className="pp-menu-secondary-row">
          <button className="lrgbtn btn-neutral min-h-[2.75rem] text-sm" style={{ width: '100%', margin: 0 }} onClick={() => navigate('stats')}>
            <ChartColumnBig className="w-4 h-4" /> Stats
          </button>

          <button className="lrgbtn btn-neutral min-h-[2.75rem] text-sm" style={{ width: '100%', margin: 0 }} onClick={() => navigate('achievements')}>
            <Medal className="w-4 h-4" /> Achievements
          </button>
        </div>
      </div>
    </div>
    {/* Daily streaks summary */}
    <div className="pp-home-streaks mt-6 mx-auto w-full max-w-xl">
      <div className="glass glass--white rounded-xl p-4">
        <h3>Your Daily Streaks</h3>
        <p>
          {hasAnyStreak(streaks)
            ? 'Keep going to earn your next postmark.'
            : 'Win a Daily Challenge to start a streak.'}
        </p>
        <div className="pp-home-streak-list">
          {DIFF_ORDER.map((d) => {
            const count = streakCount(streaks[d]);
            const milestone = nextStreakMilestone(count);
            const daysToGo = milestone ? Math.max(0, milestone.days - count) : 0;

            return (
              <div key={d} className="pp-home-streak-row">
                <div className="pp-home-streak-main">
                  <span className="pp-home-streak-diff">{DIFF_LABELS[d] ?? d}</span>
                  <span className="pp-home-streak-count" aria-label={`${count}-day streak`}>
                    {count} {count === 1 ? 'day' : 'days'}
                  </span>
                </div>

                {count > 0 && milestone && (
                  <div className="pp-home-streak-progress" aria-label={`${count} of ${milestone.days} days toward ${milestone.name}`}>
                    <div className="pp-home-streak-bar">
                      <span style={{ width: `${streakProgressPercent(count, milestone.days)}%` }} />
                    </div>
                    <div className="pp-home-streak-next">
                      {daysToGo === 0 ? milestone.name : `${daysToGo} to ${milestone.name}`}
                    </div>
                  </div>
                )}
              </div>
            );
          })}
        </div>
      </div>
    </div>

    <div className="mt-5 flex flex-wrap items-center justify-center gap-2 text-sm">
      <button className="btn btn-neutral" onClick={() => setShowAbout(true)}>
        <InfoIcon className="w-4 h-4" /> About / Feedback
      </button>
      <button className="btn btn-neutral" onClick={() => navigate('settings')}>
        <Settings2 className="w-4 h-4" /> Settings
      </button>
      <button className="btn btn-neutral" onClick={() => navigate('privacy')}>
        <Eye className="w-4 h-4" /> Privacy
      </button>
    </div>
    {/* --- Daily chooser modal --- */}
{showDailyChooser && createPortal(
  <div
    role="menu"
    onClick={() => setShowDailyChooser(false)}
    className={[
      "glass glass--slate rounded-xl shadow-lg p-2",
      "transition duration-150 ease-out",
      "transform will-change-transform will-change-opacity",
      menuAnimClass
    ].join(" ")}
    style={{
      position: 'fixed',
      inset: 0,
      background: 'rgba(0,0,0,0.6)',
      zIndex: 2147483647,
      display: 'flex',
      justifyContent: 'center',
      alignItems: 'flex-start',
      paddingTop: '10vh',
      padding: '10vh 16px 16px'
    }}
  >

    <div
      className={[
        "glass p-5 rounded-2xl shadow-lg",
        "transition duration-200 ease-out transform-gpu",
        freeAnim
      ].join(" ")}
      onClick={(e) => e.stopPropagation()}
      tabIndex={-1}
      style={{
        width: '400px', // Fixed width
        maxHeight: '80vh',
        overflowY: 'auto',
        WebkitOverflowScrolling: 'touch',
        overscrollBehavior: 'contain',
        touchAction: 'pan-y'
      }}
    >
      <h2 className="text-2xl font-bold mb-4 text-center">Choose Daily Challenge Difficulty</h2>

      <ul
        style={{
          display: 'flex',
          flexDirection: 'column',
          gap: 10,
          margin: 8,
          padding: 0,
          listStyle: 'none'
        }}
      >
        {DIFF_ORDER.map((diff) => {
          const status = getDailyStatusMeta(diff);
          return (
            <li key={diff} className="choice-item">
              <button
                type="button"
                className={`btn ${DAILY_CHOICE_BUTTON_CLASS[diff] || 'btn-primary'} btn-choice`}
                onClick={() => handleDailyChoice(diff)}
                role="menuitem"
                style={{
                  display: 'flex',
                  width: '95%',
                  padding: '0.45rem 1rem',
                  fontSize: '1.45rem',
                  alignItems: 'center',
                  justifyContent: 'space-between',
                  gap: '0.75rem',
                }}
              >
                <span>{DIFF_LABELS[diff] ?? diff}</span>
                <span className={`text-xs font-bold uppercase tracking-wide rounded-full px-2 py-1 ${status.className}`}>
                  {status.label}
                </span>
                {renderSingleFireForChooser(streaks?.[diff])}
              </button>
            </li>
          );
        })}
      </ul>
      <div className={`collapsible ${dailyChoice ? 'open' : ''}`}>
        <div className="inner">
          <div className="mt-4 p-4 rounded-xl bg-white/75 text-slate-900 text-center">
            <div className="font-semibold"><b>{dailyChoice && DIFF_LABELS[dailyChoice]}</b></div>
            <p className="text-sm mt-1 font-bold">{dailyChoice && DIFF_DESCRIPTIONS[dailyChoice]}</p>

            <div className="mt-3 flex gap-2 justify-center">
              <button
                className="btn btn-primary"
                onClick={() => {
                  startOrResumeDaily(dailyChoice);
                  setShowDailyChooser(false);
                  setDailyChoice(null);
                }}
                style={{ 
                  display: 'block', 
                  width: '98%', 
                  padding: '1rem 1rem', // Smaller padding
                  fontSize: '2rem', // Smaller text
                }}
              >
                Play Game
              </button>
            </div>
          </div>
        </div>
      </div>

      <div className="mt-4 flex justify-center">
        <button
          className="btn btn-neutral w-full max-w-[20rem]"
          onClick={() => { setShowDailyChooser(false); setDailyChoice(null); }}
        >
          Close
        </button>
      </div>

    </div>
  </div>,
  document.body
)}


    {/* --- Free Play chooser modal --- */}
{showFreePlayChooser && createPortal(
  <div
    role="menu"
    onClick={() => setShowFreePlayChooser(false)}
        className={[
      "glass glass--slate rounded-xl shadow-lg p-2",
      "transition duration-150 ease-out",
      "transform will-change-transform will-change-opacity",
      menuAnimClass
    ].join(" ")}
    style={{
      position: 'fixed',
      inset: 0,
      background: 'rgba(0,0,0,0.6)',
      zIndex: 2147483647,
      display: 'flex',
      justifyContent: 'center',
      alignItems: 'flex-start',
      paddingTop: '10vh',
      padding: '10vh 16px 16px'
    }}
  >
   <div
      className={[
        "glass p-5 rounded-2xl shadow-lg",
        "transition duration-200 ease-out transform-gpu",
        freeAnim
      ].join(" ")}
      onClick={(e) => e.stopPropagation()}
      tabIndex={-1}
      style={{
        width: '400px', // Fixed width
        maxHeight: '80vh',
        overflowY: 'auto',
        WebkitOverflowScrolling: 'touch',
        overscrollBehavior: 'contain',
        touchAction: 'pan-y'
      }}
    >
<h2 className="text-2xl font-bold mb-4 text-center">Choose Free Play Difficulty</h2>

<ul
        style={{
          display: 'flex',
          flexDirection: 'column',
          gap: 10, // Reduced gap
          margin: 8,
          padding: 0,
          listStyle: 'none'
        }}
      >
        <li className="choice-item">
          <button
            type="button"
            className="btn btn-green btn-choice"
            onClick={() => setFreeChoice('easy')}
            role="menuitem"
            style={{ 
              display: 'block', 
              width: '95%', 
              padding: '0.3rem 1rem', // Smaller padding
              fontSize: '2rem', // Smaller text
            }}
          >
            <span><>Easy</></span>
          </button>
        </li>

        <li className="choice-item">
          <button
            type="button"
            className="btn btn-yellow btn-choice"
            onClick={() => setFreeChoice('normal')}
            role="menuitem"
            style={{ 
              display: 'block', 
              width: '95%', 
              padding: '0.3rem 1rem', // Smaller padding
              fontSize: '2rem', // Smaller text
            }}
          >
            <span>Normal</span>
          </button>
        </li>

        <li className="choice-item">
          <button
            type="button"
            className="btn btn-orange btn-choice"
            onClick={() => setFreeChoice('hard')}
            role="menuitem"
            style={{ 
              display: 'block', 
              width: '95%', 
              padding: '0.3rem 1rem', // Smaller padding
              fontSize: '2rem', // Smaller text
            }}
          >
            <span>Hard</span>
          </button>
        </li>

        <li className="choice-item">
          <button
            type="button"
            className="btn btn-purple btn-choice"
            onClick={() => setFreeChoice('master')}
            role="menuitem"
            style={{ 
              display: 'block', 
              width: '95%', 
              padding: '0.3rem 1rem', // Smaller padding
              fontSize: '2rem', // Smaller text
            }}
          >
            <span>Master</span>
          </button>
        </li>
      </ul>


 <div className={`collapsible ${freeChoice ? 'open' : ''}`}>
  <div className="inner">
    <div className="mt-4 p-3 rounded-xl bg-white/75 text-slate-900">
      <div className="font-semibold">{freeChoice && DIFF_LABELS[freeChoice]}</div>
      <p className="text-sm mt-1 font-bold">{freeChoice && DIFF_DESCRIPTIONS[freeChoice]}</p>

      <div className="mt-3 flex gap-2 justify-center">
        <button
          className="btn btn-primary"
          onClick={() => {
            startWithDifficulty(freeChoice);
            setShowFreePlayChooser(false);
            setFreeChoice(null);
          }}
                          style={{ 
                  display: 'block', 
                  width: '98%', 
                  padding: '1rem 1rem', // Smaller padding
                  fontSize: '2rem', // Smaller text
                }}
        >
          Play Game
        </button>
      </div>
    </div>
  </div>
</div>

<div className="mt-4">
  <button
    className="btn btn-neutral w-full"
    onClick={() => { setShowFreePlayChooser(false); setFreeChoice(null); }}
  >
    Close
  </button>
</div>

    </div>
  </div>,
  document.body
)}


    {/* Existing About modal remains unchanged below */}
<GameModal
  open={showAbout}
  onClose={() => setShowAbout(false)}
  title="About Postcode Pursuit"
>
  <div className="space-y-5 text-slate-800">
    <section className="rounded-2xl border border-slate-200/80 bg-white/80 p-4 shadow-sm">
      <p className="text-sm leading-6 text-slate-700">
        <span className="font-semibold text-slate-900">Postcode Pursuit</span> is a daily UK
        geography puzzle. Start in one postcode area and reach the{" "}
        <span className="font-semibold text-slate-900">Target</span> by moving through adjacent
        postcode areas. It’s inspired by{" "}
        <a
          href="https://travle.earth"
          target="_blank"
          rel="noreferrer"
          className="font-medium text-indigo-600 underline decoration-indigo-300 underline-offset-2 hover:text-indigo-700"
        >
          Travle
        </a>
        .
      </p>
    </section>

    <section className="rounded-2xl border border-slate-200/80 bg-white/80 p-4 shadow-sm">
      <h3 className="mb-3 text-sm font-semibold uppercase tracking-wide text-slate-500">
        How it works
      </h3>
      <ul className="space-y-2 text-sm leading-6 text-slate-700">
        <li>Move between neighbouring UK postcode areas.</li>
        <li>
          <span className="font-medium text-slate-900">Dashed lines</span> show ferry links.
        </li>
        <li>
          <span className="font-medium text-slate-900">Solid lines</span> show major bridges and
          tunnels.
        </li>
        <li>Reach the target in as few moves as possible.</li>
      </ul>
    </section>

    <section className="rounded-2xl border border-slate-200/80 bg-white/80 p-4 shadow-sm">
      <h3 className="mb-3 text-sm font-semibold uppercase tracking-wide text-slate-500">
        Difficulty modes
      </h3>
      <div className="grid gap-3 sm:grid-cols-2">
        <div className="rounded-xl border border-slate-200 bg-slate-50 px-3 py-2">
          <div className="text-sm font-semibold text-slate-900"><u>Easy</u></div>
          <p className="mt-1 text-sm leading-5 text-slate-600">
            Outlines and labels always visible. Revisits and undo allowed.
          </p>
        </div>

        <div className="rounded-xl border border-slate-200 bg-slate-50 px-3 py-2">
          <div className="text-sm font-semibold text-slate-900"><u>Normal</u></div>
          <p className="mt-1 text-sm leading-5 text-slate-600">
            Outlines visible; labels shown for Start and visited areas. Revisits and undo allowed.
          </p>
        </div>

        <div className="rounded-xl border border-slate-200 bg-slate-50 px-3 py-2">
          <div className="text-sm font-semibold text-slate-900"><u>Hard</u></div>
          <p className="mt-1 text-sm leading-5 text-slate-600">
            No outlines or labels. No revisits. No undo.
          </p>
        </div>

        <div className="rounded-xl border border-slate-200 bg-slate-50 px-3 py-2">
          <div className="text-sm font-semibold text-slate-900"><u>Master</u></div>
          <p className="mt-1 text-sm leading-5 text-slate-600">
            Only start, current, visited and target areas are shown. No revisits. No undo.
          </p>
        </div>
      </div>
    </section>

    <section className="rounded-2xl border border-slate-200/80 bg-white/80 p-4 shadow-sm">
      <h3 className="mb-3 text-sm font-semibold uppercase tracking-wide text-slate-500">
        Daily Challenge
      </h3>
      <ul className="space-y-2 text-sm leading-6 text-slate-700">
        <li>Choose one difficulty each day.</li>
        <li>Your progress is saved automatically, so you can resume later.</li>
        <li>You get up to <span className="font-medium text-slate-900">3 hints per day</span> for each difficulty.</li>
        <li>Streaks are tracked separately for each difficulty.</li>
        <li>You can share your result once you finish.</li>
      </ul>
    </section>

    <section className="rounded-2xl border border-slate-200/80 bg-white/80 p-4 shadow-sm">
      <h3 className="mb-3 text-sm font-semibold uppercase tracking-wide text-slate-500">
        Scoring, stats and achievements
      </h3>
      <ul className="space-y-2 text-sm leading-6 text-slate-700">
        <li>Each daily puzzle has a <span className="font-medium text-slate-900">Par</span> based on the optimal route.</li>
        <li>The <span className="font-medium text-slate-900">Stats</span> page shows wins, win rate, average moves, best time and average vs Par.</li>
        <li>Unlock achievements for harder wins, perfect routes, long journeys, ferries, bridges, coverage and streaks.</li>
        <li>Some achievements stay hidden until you discover them.</li>
      </ul>
    </section>

    <section className="rounded-2xl border border-slate-200/80 bg-white/80 p-4 shadow-sm">
      <h3 className="mb-3 text-sm font-semibold uppercase tracking-wide text-slate-500">
        Controls
      </h3>
      <ul className="space-y-2 text-sm leading-6 text-slate-700">
        <li>Type a neighbouring postcode area and press <span className="font-medium text-slate-900">Enter</span>.</li>
        <li>Use the map controls to zoom or reset the view.</li>
        <li>Open the menu for New Game, Restart, Tutorial and more.</li>
        <li><span className="font-medium text-slate-900">Ctrl/Cmd + Z</span> undoes a move where undo is available.</li>
      </ul>
    </section>

    <section className="rounded-2xl border border-slate-200/80 bg-white/80 p-4 shadow-sm">
      <h3 className="mb-3 text-sm font-semibold uppercase tracking-wide text-slate-500">
        Privacy & data
      </h3>
      <ul className="space-y-2 text-sm leading-6 text-slate-700">
        <li>Your progress, stats, achievements, coverage and streaks are stored locally in your browser.</li>
        <li>Clearing site data, switching browser or using another device can reset your progress.</li>
      </ul>
    </section>

    <section className="rounded-2xl border border-indigo-200 bg-indigo-50/70 p-4 shadow-sm">
      <h3 className="mb-2 text-sm font-semibold uppercase tracking-wide text-indigo-700">
        Feedback
      </h3>
      <p className="text-sm leading-6 text-slate-700">
        Got feedback, spotted a bug, or have an idea for the game?
      </p>
      <a
        href="https://forms.gle/Hf6fgRzBSnnZCqYJ6"
        className="mt-3 inline-flex items-center rounded-xl bg-indigo-600 px-4 py-2 text-sm font-medium text-white shadow-sm transition hover:bg-indigo-700"
      >
        Send feedback
      </a><br />

    </section>
  </div>
</GameModal>



  </div>
);

// ---- Daily chooser helpers & streak state ----
const DAILY_CHOICE_BUTTON_CLASS = { easy: 'btn-green', normal: 'btn-yellow', hard: 'btn-orange', master: 'btn-purple' };

// Map whatever Daily.dailyStatus returns into { idle | continue | finished | gaveUp }
function normalizeStatus(raw) {
  const s = String(raw || '').toLowerCase();
  if (/gave|give|quit|forfeit/.test(s)) return 'gaveUp';
  if (/finish|done|complete|result/.test(s)) return 'finished';
  if (/cont|progress|resume|started|ongoing/.test(s)) return 'continue';
  return 'idle';
}

function getDailyStatusMeta(diff) {
  const status = normalizeStatus(Daily.dailyStatus?.(diff));
  if (status === 'gaveUp') return { status, label: 'Gave up', className: 'bg-rose-100 text-rose-800' };
  if (status === 'continue') return { status, label: 'Continue', className: 'bg-sky-100 text-sky-800' };
  if (status === 'finished') return { status, label: 'Result', className: 'bg-emerald-100 text-emerald-800' };
  return { status, label: 'Not played', className: 'bg-slate-100 text-slate-700' };
}

function streakCount(value) {
  if (value && typeof value === 'object') return Number(value.count) || 0;
  return Number(value) || 0;
}

function hasAnyStreak(allStreaks) {
  return DIFF_ORDER.some((diff) => streakCount(allStreaks?.[diff]) > 0);
}

function nextStreakMilestone(count) {
  return STREAK_MILESTONES.find((milestone) => count < milestone.days) || null;
}

function streakProgressPercent(count, target) {
  if (!target) return 0;
  return Math.max(2, Math.min(100, Math.round((count / target) * 100)));
}

function renderSingleFireForChooser(count) {
  const n = streakCount(count);
  return n > 0 ? (
    <span aria-label={`${n}-day streak`} title={`${n}-day streak`}>{'\u{1F525}'}</span>
  ) : null;
}
const [streaks, setStreaks] = React.useState({
  easy: 0, normal: 0, hard: 0, master: 0
});

React.useEffect(() => {
  setStreaks({
    easy: readStreak('easy'),
    normal: readStreak('normal'),
    hard: readStreak('hard'),
    master: readStreak('master'),
  });
  // If you emit an event when a daily is completed, add it to the deps.
}, [readStreak]);

// Route pages that replace the app UI
if (route === 'stats') {
  return (
    <StatsPage
      key={statsVersion}
      stats={computeStats()}
      onBack={() => navigate('')}
      onResetAll={resetAllStats}
    />
  );
}
if (route === 'achievements') {
  return (
    <AchievementsPage
      key={statsVersion}                // force re-mount after resets/merges
      onBack={() => navigate('')}
      achievements={achievements}
      visitedCount={getLifetimeVisitedCount()}   // ← lifetime, cloud-merged
      totalAreas={Object.keys(postcodeAreas).length}
    />
  );
}

if (route === 'settings') {
  return (
    <Settings
      onBack={() => navigate('')}
      uiTheme={uiTheme}
      onUiThemeChange={setUiTheme}
      colorblindFriendly={colorblindFriendly}
      onColorblindFriendlyChange={setColorblindFriendly}
      inputMode={inputMode}
      onInputModeChange={setInputMode}
      largeControls={largeControls}
      onLargeControlsChange={setLargeControls}
      mapStyle={mapStyle}
      onMapStyleChange={setMapStyle}
      textSize={textSize}
      onTextSizeChange={setTextSize}
    />
  );
}

if (route === 'privacy') {
  return (
    <PrivacyPolicy
      onBack={() => navigate('')}
    />
  );
}



return (
  <>

    <div className="min-h-screen w-full bg-gradient-to-br from-slate-50 via-indigo-50 to-purple-50">
      {gameState === 'menu' ? renderMenu() : (
        <div className="pp-game-screen">
          {renderGameBoard()}
        </div>
      )}
    </div>

    <OnboardingTutorial
      isOpen={consentResolved && showTutorial}
      onSkip={() => { localStorage.setItem(ONBOARDING_KEY, 'true'); setShowTutorial(false); }}
      onComplete={() => { localStorage.setItem(ONBOARDING_KEY, 'true'); setShowTutorial(false); }}
      postcodeAreas={postcodeAreas}
    />

    {leaveConfirmOpen && createPortal(
  <div
    style={{
      position: 'fixed',
      inset: 0,
      background: 'rgba(0,0,0,0.6)',
      zIndex: 2147483647,
      display: 'flex',
      justifyContent: 'center',
      alignItems: 'flex-start',
      paddingTop: '10vh',
      padding: '10vh 16px 16px'
    }}
    onClick={() => setLeaveConfirmOpen(false)}
    role="dialog"
    aria-modal="true"
    aria-labelledby="leave-title"
  >
    <div
      className="glass p-5 rounded-2xl shadow-xl text-center"
      style={{
        maxWidth: 520,
        width: '92vw',
        maxHeight: '80vh',
        overflowY: 'auto',
        WebkitOverflowScrolling: 'touch',
        overscrollBehavior: 'contain',
        touchAction: 'pan-y'
      }}
      onClick={(e) => e.stopPropagation()}
    >
      <h2 id="leave-title" className="text-xl font-semibold mb-2">Leave this game?</h2>
      <p className="mb-4">
        You’ll <b>lose your current Free Play progress</b> for this round.<br/>
        Current route: <b>{Math.max(0, currentPath.length - 1)}</b> moves
        {optimalPath.length > 0 && <> · Optimal: <b>{Math.max(0, optimalPath.length - 1)}</b></>}
      </p>
      <div className="flex gap-2 justify-center">
        <button
          className="btn btn-warn glass"
          onClick={() => {
            setLeaveConfirmOpen(false);
            abandonIfActive('menu');    // analytics-safe
            clearAchievementToasts();
            setGameState('menu');
            setBurgerOpen(false);
          }}
        >
          Leave
        </button>
        <button className="btn btn-neutral glass" onClick={() => setLeaveConfirmOpen(false)}>
          Stay
        </button>
      </div>
    </div>
  </div>,
  document.body
)}


    {victoryOpen && createPortal(
      <div style={{
        position: 'fixed',
        inset: 0,
        background: 'rgba(0,0,0,0.6)',
        zIndex: 2147483647,
        display: 'flex',
        justifyContent: 'center',
        alignItems: 'flex-start',
        paddingTop: '10vh',
        padding: '10vh 16px 16px'
      }}>
        <div className="glass p-5 rounded-2xl shadow-xl text-center" style={{
          maxWidth: 520,
          width: '92vw',
          maxHeight: '80vh',
          overflowY: 'auto'
        }}>
          <h2 className="text-xl font-semibold mb-2">Victory! 🎉</h2>
          <p className="mb-4">
            From <b>{startArea}</b> to <b>{targetArea}</b><br />
            Moves: <b>{Math.max(0, currentPath.length - 1)}</b><br />
            Optimal: <b>{Math.max(0, optimalPath.length - 1)}</b><br />
            {parLine}<br />
            
             {dailyMode && (streaks?.[dailyDifficulty] ?? 0) > 0 && (
   <>Streak: <b>{streaks[dailyDifficulty]}</b> · </>
 )}
            {elapsedMs > 0 && <>Time: <b>{formatTime(elapsedMs)}</b></>}
          </p>
          <div className="flex gap-2 justify-center">
            <button onClick={shareResult} className="btn btn-purple glass">Share</button>


            <button
  onClick={() => {
    if (dailyMode) {
      setVictoryOpen(false);
      setGameState('menu'); // or show the completed daily again
    } else {
      startNewGame();
    }
  }}
  className="btn btn-warn glass"
>
  {dailyMode ? 'Back to Menu' : 'Play again'}
</button>


            <button onClick={() => setVictoryOpen(false)} className="btn btn-primary glass">Close</button>
            <div>    <a className="btn btn-primary mt-2" href="https://forms.gle/Hf6fgRzBSnnZCqYJ6">
      Send Feedback
    </a></div>
          </div>
        </div>
      </div>,
      document.body
    )}
  </>
);
}
